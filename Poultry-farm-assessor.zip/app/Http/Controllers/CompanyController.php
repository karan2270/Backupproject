<?php

namespace App\Http\Controllers;

use App\Model\Company;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\DataTables;

class CompanyController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function addCompany()
    {
        $company = null;
        $routeToSave = route('save-company');
        return view('company.form', compact('company', 'routeToSave'));
    }

    public function saveCompany(Request $request)
    {

        $valuesToSave = $this->validate($request, Company::$rules);
        $valuesToSave['created_by'] = Auth::id();

        if (Company::create($valuesToSave)) {
            $this->notifySuccess('Company Created');
        } else {
            $this->notifyError('Something went wrong!');
        }

        return redirect()->route('home');
    }

    public function companyDetails(Request $request)
    {
        return DataTables::of(Company::query())
            ->addColumn('actions', function ($company) {
                $divs = "<div class='d-flex'>";
                $edit = "<a class='btn btn-sm btn-primary mr-1' href='" . route('edit-company', ['company_id' => $company->id]) . "'><i class='fa fa-pen'></i></a>";
                $delete = "<form method='post' class='mr-1' action='" .
                    route('delete-company', ['company_id' => $company->id]) . "'>"
                    . csrf_field()
                    . method_field('DELETE')
                    . " <button class='btn btn-sm btn-danger' type='submit' onclick='return confirm(\"Are you sure?\")'><i class='fa fa-trash'></i></button></form>";
                $evaluationList = "<a class='btn btn-sm btn-primary' href='" . route('company-location-list', ['company_id' => $company->id]) . "'><i class='fa fa-list'></i></a>";

                $dive = "</div>";
                return $divs . $edit . $delete . $evaluationList . $dive;
            })
            ->rawColumns(['actions'])
            ->toJson();
    }

    public function editCompany($company_id)
    {
        $this->checkCompany($company_id);
        $company = Company::findOrFail($company_id);
        $routeToSave = route('update-company', ['company_id' => $company_id]);
        return view('company.form', compact('company', 'routeToSave'));
    }

    public function updateCompany(Request $request, $company_id)
    {
        $this->checkCompany($company_id);

        $valuesToSave = $this->validate($request, Company::$rules);
        $company = Company::findOrFail($company_id);

        if ($company->update($valuesToSave)) {
            $this->notifySuccess('company Updated');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('home');
    }


    public function deleteCompany(Request $request, $company_id)
    {
        $this->checkCompany($company_id);

        $count = Company::find($company_id)->forceDelete();

        if ($count == 1) {
            $this->notifySuccess('Company Deleted');
        } else {
            $this->notifyError('Something went wrong!');
        }

        return redirect()->route('home');
    }

    public function locationList($company_id)
    {
        $this->checkCompany($company_id);

        $company = Company::with('companyLocation')->findOrFail($company_id);

        $breadcrumbs = [
            ['title' => 'Location', 'link' => '', 'active' => true]
        ];

        return view('company.details', compact('company', 'breadcrumbs'));
    }

}

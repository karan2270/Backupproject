<?php

namespace App\Http\Controllers;

use App\Model\Company;
use App\Model\CompanyLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\DataTables;

class CompanyLocationController extends Controller
{
    public function addCompanyLocation($company_id)
    {
        $this->checkCompany($company_id);

        $company = Company::findOrFail($company_id);
        $companyLocation = null;

        $routeToSave = route('save-company-location', ['company_id' => $company_id]);

        return view('company-location.form', compact('company', 'companyLocation', 'routeToSave'));
    }

    public function saveCompanyLocation(Request $request, $company_id)
    {
        $this->checkCompany($company_id);

        $valuesToSave = $this->validate($request, CompanyLocation::$rules);
        $valuesToSave['created_by'] = Auth::id();

        $valuesToSave['company_id'] = $request->company_id;

        if (CompanyLocation::create($valuesToSave)) {
            $this->notifySuccess('Company Location Created');
        } else {
            $this->notifyError('Something went wrong!');
        }

        return redirect()->route('company-location-list', ['company_id' => $company_id]);
    }

    public function datatable($company_id)
    {

        return DataTables::of(CompanyLocation::OfCompany($company_id))
            ->addColumn('actions', function ($companyLocation) {
                $divs = "<div class='d-flex'>";
                $edit = "<a class='btn btn-sm btn-primary mr-1' href='" . route('Company-location-edit', ['company_id' => $companyLocation->company_id, 'company_location_id' => $companyLocation->id]) . "'><i class='fa fa-pen'></i></a>";
                $delete = "<form method='post' class='mr-1' action='" .
                    route('delete-company-location', ['company_id' => $companyLocation->company_id, 'company_location_id' => $companyLocation->id]) . "'>"
                    . csrf_field()
                    . method_field('DELETE')
                    . " <button class='btn btn-sm btn-danger' type='submit' onclick='return confirm(\"Are you sure?\")'><i class='fa fa-trash'></i></button></form>";
                $evaluationList = "<a class='btn btn-sm btn-primary' href='" . route('company-evaluation-list', ['company_id' => $companyLocation->company_id, 'company_location_id' => $companyLocation->id]) . "'><i class='fa fa-list'></i></a>";

                return $divs . $edit . $delete . $evaluationList;
            })
            ->rawColumns(['actions'])
            ->toJson();
    }

    public function editCompanyLocation($company_id, $company_location_id)
    {
        $company = Company::findOrFail($company_id);
        $this->checkCompanyLocation($company_id, $company_location_id);

        $companyLocation = CompanyLocation::findOrFail($company_location_id);
        $routeToSave = route('update-company-location', ['company_id' => $company_id, 'company_location_id' => $company_location_id]);
        return view('company-location.form', compact('company', 'companyLocation', 'routeToSave'));
    }

    public function updateCompanyLocation(Request $request, $company_id, $company_location_id)
    {

        $this->checkCompanyLocation($company_id, $company_location_id);

        $valuesToSave = $this->validate($request, CompanyLocation::$rules);

        $farm = CompanyLocation::findOrFail($company_location_id);

        if ($farm->update($valuesToSave)) {
            $this->notifySuccess('Company Location Updated');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('company-location-list', ['company_id' => $company_id]);
    }

    public function deleteCompanyLocation(Request $request, $company_id, $company_location_id)
    {
        $this->checkCompanyLocation($company_id, $company_location_id);

        $count = CompanyLocation::find($company_location_id)->forceDelete();

        if ($count == 1) {
            $this->notifySuccess('Company Location Deleted');
        } else {
            $this->notifyError('Something went wrong!');
        }

        return redirect()->route('company-location-list', ['company_id' => $company_id]);
    }

    public function evaluationList($companyId, $companyLocationId)
    {
        $this->checkCompanyLocation($companyId, $companyLocationId);

        $breadcrumbs = [
            ['title' => 'Location', 'link' => route('company-location-list', ['company_id' => $companyId]), 'active' => false],
            ['title' => 'Evaluation', 'link' => '', 'active' => true]
        ];

        $companyEvaluation = CompanyLocation::with('companyEvaluation')->findOrFail($companyLocationId);

        return view('company-location.details', compact('companyEvaluation', 'companyId', 'companyLocationId', 'breadcrumbs'));
    }
}

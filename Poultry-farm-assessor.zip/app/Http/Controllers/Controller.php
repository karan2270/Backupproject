<?php

namespace App\Http\Controllers;

use App\Model\Assessor;
use App\Model\Company;
use App\Model\CompanyEvaluation;
use App\Model\CompanyLocation;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function notify($message, $notifyClass)
    {
        Session::flash('notify', $message);
        Session::flash('notify-class', $notifyClass);
    }

    public function notifyError($message)
    {
        $this->notify($message, 'alert-danger border-danger');
    }

    public function notifySuccess($message)
    {
        $this->notify($message, 'alert-success border-success');
    }

    public function notifyWarning($message)
    {
        $this->notify($message, 'alert-warning border-warning');
    }

    public function notifyInfo($message)
    {
        $this->notify($message, 'alert-info border-info');
    }

    public function checkCompany($company_id)
    {
        if (Auth::user()->is_admin === true) {
            return;
        }

        $company = Company::findByAuthUser($company_id)->get()->first();

        if (empty($company)) {
            abort(404);
        }
    }

    public function checkCompanyLocation($company_id, $company_location_id)
    {
        if (Auth::user()->is_admin === true) {
            return;
        }

        $this->checkCompany($company_id);

        $companyLocation = CompanyLocation::findByAuthUser($company_location_id)
            ->ofCompany($company_id)
            ->get()->first();

        if (empty($companyLocation)) {
            abort(404);
        }
    }

    public function checkCompanyEvaluation($company_id, $company_location_id, $company_evaluation_id)
    {
        if (Auth::user()->is_admin === true) {
            return;
        }

        $this->checkCompanyLocation($company_id, $company_location_id);

        $companyEvaluation = CompanyEvaluation::findByAuthUser($company_evaluation_id)
            ->OfLocation($company_location_id)
            ->get()->first();

        if (empty($companyEvaluation)) {
            abort(404);
        }
    }

    public function checkAssessorBroiler($company_id, $company_location_id, $company_evaluation_id,$company_assessor_id)
    {
        if (Auth::user()->is_admin === true) {
            return;
        }
        $this->checkCompanyEvaluation($company_id, $company_location_id, $company_evaluation_id);

        $companyAssessor = Assessor::findByAuthUser($company_assessor_id)->get()->first();

        if (empty($companyAssessor)) {
            abort(404);
        }
    }

    public function checkAssessor($type, $company_evaluation_id)
    {
        $assessor = null;
        switch ($type) {
            case 'broiler':
                $assessor = Assessor::where('company_evaluation_id', $company_evaluation_id)->where('created_by', Auth::id())->get()->toArray();
                break;
        }
        return !empty($assessor);
    }
}


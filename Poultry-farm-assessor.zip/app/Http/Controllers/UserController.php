<?php

namespace App\Http\Controllers;

use App\Model\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Yajra\DataTables\DataTables;

class UserController extends Controller
{
    public function login(Request $request)
    {
        $email = $request->email;
        $password = $request->password;

        if (!Auth::attempt(['email' => $email, 'password' => $password])) {
            return response('not_found', 404);
        }

        return Auth::user();
    }

    public function addUser()
    {
        $user = null;
        $routeToSave = route('save-user');
        return view('users.add', compact('user', 'routeToSave'));
    }

    public function saveUser(Request $request)
    {
        $valuesToSave = $this->validate($request, User::$rules);
        $valuesToSave['password'] = Hash::make($request['password']);
          $valuesToSave['api_token'] = Str::random(60);

        if (User::create($valuesToSave)) {
            $this->notifySuccess('User Created');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('user-list');
    }

    public function userList()
    {
        $users = User::all();
        return view('users.details', compact('users'));
    }

    public function datatable()
    {
        return DataTables::of(User::all())
            ->addColumn('actions', function ($user) {
                $divs = "<div class='d-flex'>";
                $edit = "<a class='btn btn-sm btn-primary mr-1' href='" . route('edit-user', ['user_id' => $user->id]) . "'><i class='fa fa-pen'></i></a>";
                $dive = "</div>";
                return $divs . $edit . $dive;
            })
            ->rawColumns(['actions'])
            ->toJson();
    }

    public function editUser($user_id)
    {
        $user = User::findOrFail($user_id);
        $routeToSave = route('update-user', ['user_id' => $user_id]);
        return view('users.add', compact('user', 'routeToSave'));
    }

    public function updateUser(Request $request, $user_id)
    {
        $user = User::findOrFail($user_id);
        $rules = User::$rules;
        $rules['email'] = 'required|string|email|max:255|unique:users,email,' . $user->id;

        if (!$request->password) {
            $rules['password'] = 'sometimes';
            unset($request['password']);
            $valuesToSave = $this->validate($request, $rules);
        } else {
            $valuesToSave = $this->validate($request, $rules);
            $valuesToSave['password'] = Hash::make($request['password']);
        }
        if ($user->update($valuesToSave)) {
            $this->notifySuccess('User Updated');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('user-list');
    }

    public function deleteUser(Request $request, $user_id)
    {
        $count = User::find($user_id)->forceDelete();
        if ($count == 1) {
            $this->notifySuccess('User Deleted');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('user-list');
    }

}


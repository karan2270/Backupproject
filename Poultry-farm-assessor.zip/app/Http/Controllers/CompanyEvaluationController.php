<?php

namespace App\Http\Controllers;

use App\Model\Company;
use App\Model\CompanyEvaluation;
use App\Model\CompanyLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Yajra\DataTables\DataTables;

class CompanyEvaluationController extends Controller
{
    public function addCompanyEvaluation($company_id, $company_location_id)
    {
        $this->checkCompanyLocation($company_id, $company_location_id);
        $companyEvaluation = CompanyLocation::findOrFail($company_location_id);
        $company = Company::findorfail($company_id);
        $company_location = CompanyLocation::findorFail($company_location_id);
        $companyEvaluationLocation = null;
        $routeToSave = route('save-company-evaluation', ['company_id' => $company_id, 'company_location_id' => $company_location_id]);
        return view('company-evaluation.form', compact('companyEvaluation', 'companyEvaluationLocation', 'routeToSave', 'company', 'company_location'));
    }

    public function saveCompanyEvaluation(Request $request, $company_id, $company_location_id)
    {

        $this->checkCompanyLocation($company_id, $company_location_id);
        $valuesToSave = $this->validate($request, CompanyEvaluation::$rules);

        $valuesToSave['created_by'] = Auth::id();

        if (CompanyEvaluation::create($valuesToSave)) {
            $this->notifySuccess('Company Evaluation Created');
        } else {
            $this->notifyError('Something went wrong!');
        }

        return redirect()->route('company-evaluation-list', ['company_id' => $company_id, 'company_location_id' => $company_location_id]);
    }

    public function datatable($company_location_id)
    {

        return DataTables::of(CompanyEvaluation::OfLocation($company_location_id))
            ->addColumn('actions', function ($companyEvaluation) {
                $divs = "<div class='d-flex'>";
                $edit = "<a class='btn btn-sm btn-primary mr-1' href='" . route('Company-evaluation-edit', ['company_location_id' => $companyEvaluation->company_location_id, 'company_evaluation_id' => $companyEvaluation->id]) . "'><i class='fa fa-pen'></i></a>";
                $delete = "<form method='post' class='mr-1' action='" .
                    route('delete-company-evaluation', ['company_location_id' => $companyEvaluation->company_location_id, 'company_evaluation_id' => $companyEvaluation->id]) . "'>"
                    . csrf_field()
                    . method_field('DELETE')
                    . " <button class='btn btn-sm btn-danger' type='submit' onclick='return confirm(\"Are you sure?\")'><i class='fa fa-trash'></i></button></form>";

                return $divs . $edit . $delete;
            })
            ->rawColumns(['actions'])
            ->toJson();
    }

    public function editCompanyEvaluation($company_id, $company_location_id, $company_evaluation_id)
    {
        $this->checkCompanyEvaluation( $company_id, $company_location_id, $company_evaluation_id);
        $company = Company::findorfail($company_id);
        $company_location = CompanyLocation::findorFail($company_location_id);

        $companyEvaluation = CompanyLocation::findOrFail($company_location_id);

        $companyEvaluationLocation = CompanyEvaluation::findOrFail($company_evaluation_id);
        $routeToSave = route('update-company-evaluation', ['company_id' => $company_id, 'company_location_id' => $company_location_id, 'company_evaluation_id' => $company_evaluation_id]);
        return view('company-evaluation.form', compact('companyEvaluation', 'companyEvaluationLocation', 'routeToSave', 'company', 'company_location'));
    }

    public function updateCompanyEvaluation(Request $request, $company_id, $company_location_id, $company_evaluation_id)
    {
        $this->checkCompanyEvaluation($company_id,$company_location_id, $company_evaluation_id);

        $valuesToSave = $this->validate($request, CompanyEvaluation::$rules);
        $farm = CompanyEvaluation::findOrFail($company_evaluation_id);

        if ($farm->update($valuesToSave)) {
            $this->notifySuccess('Company Evaluation Updated');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('company-evaluation-list', ['company_id' => $company_id, 'company_location_id' => $company_location_id]);
    }

    public function deleteCompanyEvaluation(Request $request, $company_id, $company_location_id, $company_evaluation_id)
    {
        $this->checkCompanyEvaluation($company_id,$company_location_id, $company_evaluation_id);
        $count = CompanyEvaluation::find($company_evaluation_id)->forceDelete();

        if ($count == 1) {
            $this->notifySuccess('Company Evaluation Deleted');
        } else {
            $this->notifyError('Something went wrong!');
        }

        return redirect()->route('company-evaluation-list', ['company_id' => $company_id, 'company_location_id' => $company_location_id]);
    }

    public function assessorList($company_id, $company_location_id, $company_evaluation_id)
    {
        $this->checkCompanyEvaluation($company_id, $company_location_id, $company_evaluation_id);

        $company_location = CompanyLocation::findorFail($company_location_id);
        $companyEvaluation = CompanyEvaluation::findOrFail($company_evaluation_id);
        $liveBroiler = $this->checkAssessor('broiler', $company_evaluation_id);

        $breadcrumbs = [
            ['title' => 'Location', 'link' => route('company-location-list', ['company_id' => $company_id]), 'active' => false],
            [
                'title' => 'Evaluation',
                'link' => route('company-evaluation-list', ['company_id' => $company_id, 'company_location_id' => $company_location_id]),
                'active' => false
            ],
            ['title' => 'Assessor', 'link' => '', 'active' => true]
        ];

        return view('company-evaluation.details', compact('company_id', 'companyEvaluation', 'company_location', 'liveBroiler', 'breadcrumbs'));

    }
}

<?php

namespace App\Http\Controllers;

use App\Model\Assessor;
use App\Model\Company;
use App\Model\CompanyEvaluation;
use App\Model\CompanyLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class LiveBroilerController extends Controller
{
    public function addAssessor($company_id, $company_location_id, $company_evaluation_id)
    {
        $this->checkCompanyEvaluation($company_id, $company_location_id, $company_evaluation_id);
        $company = Company::findorFail($company_id);

        $company_location = CompanyLocation::findorFail($company_location_id);
//        $this->checkCompany($company_evaluation_id);
        $companyEvaluation = CompanyEvaluation::findOrFail($company_evaluation_id);
        $companyAssessor = null;
        $routeToSave = route('save-assessor-live-broiler', ['company_id' => $company_id, 'company_location_id' => $company_location_id, 'company_evaluation_id' => $company_evaluation_id]);
        return view('assessor.form', compact('companyAssessor', 'companyEvaluation', 'routeToSave', 'company', 'company_location'));
    }

    public function saveAssessor(Request $request, $company_id, $company_location_id, $company_evaluation_id)
    {
        $this->checkCompanyEvaluation($company_id, $company_location_id, $company_evaluation_id);

        $valuesToSave = $this->validate($request, Assessor::$rules);

        $valuesToSave['created_by'] = Auth::id();

        foreach ($valuesToSave as $key => $value) {
            if (!(String)$value) {
                unset($valuesToSave[$key]);
            }
        }
        if (Assessor::create($valuesToSave)) {
            $this->notifySuccess('Live Broiler Created');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('company-assessor-view', ['company_id' => $company_id, 'company_location_id' => $company_location_id, 'company_evaluation_id' => $company_evaluation_id]);

    }

    public function viewAssessor($company_id, $company_location_id, $company_evaluation_id)
    {
        $this->checkCompanyEvaluation($company_id, $company_location_id, $company_evaluation_id);
        $company = Company::findorFail($company_id);
        $company_location = CompanyLocation::findorFail($company_location_id);
        $liveBroilerData = Assessor::OfLiveBroiler($company_evaluation_id)->where('created_by', Auth::id())->first()->toArray();


        $liveBroilerData['date_of_entry'] = ($liveBroilerData['number_animals'] * $liveBroilerData['chick_weight']) / 1000;
        $liveBroilerData['transport_weight_loss'] = ($liveBroilerData['truck_weight_farm_exit'] - $liveBroilerData['truck_weight_abattoir_arrival']) * 100 / $liveBroilerData['truck_weight_farm_exit'];
        $liveBroilerData['liveability'] = 100 - ($liveBroilerData['mortality'] + $liveBroilerData['culling']);
        $liveBroilerData['live birds for abattoir'] = $liveBroilerData['number_animals'] * ($liveBroilerData['liveability'] / 100) *
            ($liveBroilerData['final_weight'] / 1000);

        // todo confirm about values and its limit/range
        $fcrValueTODevice = ($liveBroilerData['final_weight'] - $liveBroilerData['chick_weight']) / 1000;

        if ($fcrValueTODevice === 0) {
            $fcrValueTODevice = 1;
        }

        $liveBroilerData['FCR'] =
            (
                $liveBroilerData['feed_consumption_1'] +
                $liveBroilerData['feed_consumption_2'] +
                $liveBroilerData['feed_consumption_3'] +
                $liveBroilerData['feed_consumption_4']
            ) / $fcrValueTODevice;

        $liveBroilerData['Mortality and culling'] = ($liveBroilerData['number_animals'] * ($liveBroilerData['liveability'] / 100));

        $liveBroilerData['Adjusted FCR'] = $liveBroilerData['total_consumption__feed'] / $liveBroilerData['live birds for abattoir'];
        $liveBroilerData['Average Daily Gain'] = ($liveBroilerData['final_weight'] - $liveBroilerData['chick_weight']) / $liveBroilerData['growing_period'];
        $liveBroilerData['Average Daily Feed Intake'] = ($liveBroilerData['feed_consumption_1'] + $liveBroilerData['feed_consumption_2'] + $liveBroilerData['feed_consumption_3'] + $liveBroilerData['feed_consumption_4']) / $liveBroilerData['growing_period'] * 1000;
        $liveBroilerData['Total Feed Cost per bird'] = ($liveBroilerData['feed_consumption_1'] * $liveBroilerData['feed_cost_1']) + ($liveBroilerData['feed_consumption_2'] * $liveBroilerData['feed_cost_2']) + ($liveBroilerData['feed_consumption_3'] * $liveBroilerData['feed_cost_3']) + ($liveBroilerData['feed_consumption_4'] * $liveBroilerData['feed_cost_4']);

        $avgFeedCost = ($liveBroilerData['feed_consumption_1'] + $liveBroilerData['feed_consumption_2'] + $liveBroilerData['feed_consumption_3'] + $liveBroilerData['feed_consumption_4']);

        if ($avgFeedCost === 0) {
            $avgFeedCost = 1;
        }

        $liveBroilerData['Avg Feed Cost'] = $liveBroilerData['Total Feed Cost per bird'] / $avgFeedCost;

        $liveBroilerData['Cost Of Availa Inclusion'] = ($liveBroilerData['availa_zinc'] * $liveBroilerData['availa_zinc_cost']) + ($liveBroilerData['availa_manganese'] * $liveBroilerData['avail_maanganese_cost']) +
            ($liveBroilerData['availa_copper'] * $liveBroilerData['availa_copper_cost'] + $liveBroilerData['availa_chromium'] + $liveBroilerData['availa_chromium_cost'] +
                $liveBroilerData['availa_selenium'] * $liveBroilerData['availa_selenium_cost']);
        $liveBroilerData['Value of Sale'] = $liveBroilerData['market_price'] * $liveBroilerData['live birds for abattoir'];

        $liveBroilerData['Income'] = $liveBroilerData['Value of Sale'] - ($liveBroilerData['Avg Feed Cost'] * $liveBroilerData['total_consumption__feed']) - ($liveBroilerData['Cost Of Availa Inclusion'] * ($liveBroilerData['total_consumption__feed'] / 1000));

        $breadcrumbs = [
            ['title' => 'Location', 'link' => route('company-location-list', ['company_id' => $company_id]), 'active' => false],
            [
                'title' => 'Evaluation',
                'link' => route('company-evaluation-list', ['company_id' => $company_id, 'company_location_id' => $company_location_id]),
                'active' => false
            ],
            ['title' => 'Assessor',
                'link' => route('company-assessor-list', ['company_id' => $company->id, 'company_location_id' => $company_location->id, 'company_evaluation_id' => $liveBroilerData['company_evaluation_id']])
                , 'active' => false],
            ['title' => 'View',
                'link' => ''
                , 'active' => true]
        ];


        return view('assessor.view', compact('liveBroilerData', 'breadcrumbs', 'company_location', 'company'));

    }

    public function editAssessor($company_id, $company_location_id, $company_evaluation_id, $company_assessor_id)
    {
        $this->checkAssessorBroiler($company_id, $company_location_id, $company_evaluation_id, $company_assessor_id);

        $company = Company::findorFail($company_id);
        $company_location = CompanyLocation::findorFail($company_location_id);

        $companyEvaluation = CompanyEvaluation::findOrFail($company_evaluation_id);
        $companyAssessor = Assessor::findorfail($company_assessor_id);
        $routeToSave = route('update-assessor-liveBroiler', ['company_id' => $company_id, 'company_location_id' => $company_location_id, 'company_evaluation_id' => $company_evaluation_id, 'company_assessor_id' => $company_assessor_id]);
        return view('assessor.form', compact('companyAssessor', 'companyEvaluation', 'routeToSave', 'company', 'company_location'));
    }

    public function updateAssessor(Request $request, $company_id, $company_location_id, $company_evaluation_id, $company_assessor_id)
    {
        $this->checkAssessorBroiler($company_id, $company_location_id, $company_evaluation_id, $company_assessor_id);

        $valuesToSave = $this->validate($request, Assessor::$rules);
        $assessor = Assessor::findOrFail($company_assessor_id);

        foreach ($valuesToSave as $key => $value) {
            if (!(String)$value) {
                unset($valuesToSave[$key]);
            }
        }
        if ($assessor->update($valuesToSave)) {
            $this->notifySuccess('Company Assessor LiveBroiler Updated');
        } else {
            $this->notifyError('Something went wrong!');
        }
        return redirect()->route('company-assessor-view', ['company_id' => $company_id, 'company_location_id' => $company_location_id, 'company_evaluation_id' => $company_evaluation_id]);
    }
}

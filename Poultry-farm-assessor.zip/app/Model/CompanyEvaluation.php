<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class CompanyEvaluation extends Model
{
    protected $table = 'company_evaluations';

    protected $fillable = [
        'company_location_id',
        'first_name',
        'last_name',
        'email',
        'phone',
        'description',
        'date',
        'created_by'
    ];

    static $rules = [
        'company_location_id' => 'required',
        'first_name' => 'required',
        'last_name' => 'required',
        'email' => 'nullable|email',
        'phone' => 'nullable',
        'description' => 'nullable',
        'date' => 'nullable',
    ];

    public function scopeOfLocation($query, $company_location_id)
    {
        $query->where('company_location_id', $company_location_id);
    }

    public function companyLocation()
    {
        return $this->belongsTo(CompanyLocation::class, 'company_location_id', 'id');
    }

    public function companyLocationOfAuthUser()
    {
        return $this->belongsTo(CompanyLocation::class, 'company_location_id', 'id')->where('created_by', Auth::id());
    }

    public function scopeFindByAuthUser($query, $id)
    {
        $query->where(['created_by' => Auth::id(), 'id' => $id]);
    }
}

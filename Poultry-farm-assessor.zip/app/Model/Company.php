<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Company extends Model
{
    protected $table = 'companies';

    protected $fillable = [
        'company_name',
        'contact_name',
        'email',
        'phone',
        'address',
        'country',
        'created_by'
    ];

    static $rules = [
        'company_name' => 'required',
        'contact_name' => 'nullable',
        'email' => 'nullable|email',
        'phone' => 'nullable',
        'address' => 'nullable',
        'country' => 'nullable'
    ];

    public function companyLocation()
    {
        return $this->hasMany(CompanyLocation::class, 'company_id', 'id');
    }

    public function scopeFindByAuthUser($query, $id)
    {
        $query->where(['created_by' => Auth::id(), 'id' => $id]);
    }
}

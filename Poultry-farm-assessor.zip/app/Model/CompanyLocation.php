<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class CompanyLocation extends Model
{
    protected $table = 'company_locations';

    protected $fillable = [
        'company_id',
        'type_location',
        'name_location',
        'email',
        'phone',
        'address',
        'contact_name',
        'country',
        'created_by'
    ];

    static $rules = [
        'type_location' => 'required',
        'name_location' => 'required',
        'email' => 'nullable|email',
        'phone' => 'nullable',
        'address' => 'nullable',
        'contact_name' => 'nullable',
        'country' => 'nullable'
    ];

    public function scopeOfCompany($query, $company_id)
    {
        $query->where('company_id', $company_id);
    }

    public function companyEvaluation()
    {
        return $this->hasMany(CompanyEvaluation::class, 'company_location_id', 'id');
    }

    public function company()
    {
        return $this->belongsTo(Company::class,'company_id','id');
    }

    public function companyOfAuthUser(){
        return $this->belongsTo(Company::class,'company_id','id')->where(['created_by' => Auth::id()]);
    }

    public function scopeFindByAuthUser($query, $id)
    {
        $query->where(['created_by' => Auth::id(), 'id' => $id]);
    }
}

<?php

namespace App\Helper;


class TypeHelper
{

    public static function stringValueOrNull($value)
    {
        if (!isset($value) || is_bool($value) || empty($value)) {
            return null;
        }

        return $value;
    }

    public static function stringOrString($value1, $value2)
    {
        if (is_null(self::stringValueOrNull($value1))) {
            return self::stringValueOrNull($value2);
        }
        return $value1;
    }

    public static function numericOrNull($value)
    {
        if (isset($value) && is_numeric($value)) {
            return $value;
        }
        return null;
    }

    public static function toBool($value)
    {
        if (!is_string($value)) return (bool)$value;
        switch (strtolower($value)) {
            case '1':
            case 'true':
            case 'on':
            case 'yes':
            case 'y':
                return true;
            default:
                return false;
        }
    }

    public static function toBooleanString($value)
    {
        return self::toBool($value) ? 'true' : 'false';
    }

    public static function arrayToJsonOrNull($value)
    {
        if (is_array($value)) {
            return json_encode($value);
        }

        return null;
    }

    public static function valueOrNothing($value)
    {
        if (is_null($value) || empty($value)) {
            return ' - ';
        }
        return $value;
    }

    public static function nullOrEmpty($value)
    {
        return (is_null($value) || empty($value));
    }

    public static function ifArrayThenFirstOrNull($arrayToCheck)
    {
        if (is_array($arrayToCheck)) {
            if (count($arrayToCheck) > 0) {
                return $arrayToCheck[0];
            }
        }
        return null;
    }

}

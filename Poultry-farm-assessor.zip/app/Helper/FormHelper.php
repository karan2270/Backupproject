<?php

function setFormComponentValue($objOrArray, $fieldKey, $default = null)
{
    $valueToSend = null;

    if (count(old()) > 0 || is_null($objOrArray)) {
        $objOrArray = old();
    }
    if (is_array($objOrArray)) {
        if (isset($objOrArray[$fieldKey])) {
            $valueToSend = $objOrArray[$fieldKey];
        }
    } elseif (is_object($objOrArray)) {
        $valueToSend = $objOrArray->{$fieldKey};
    }

    return is_null($valueToSend) ? $default : $valueToSend;
}




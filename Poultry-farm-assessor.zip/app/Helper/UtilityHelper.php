<?php

function setRouteActiveClass($routes, $activeClass = 'active', $notActiveClass = '')
{
    if (is_array($routes)) {
        foreach ($routes as $route) {
            if (Request::is($route)) {
                return $activeClass;
            }
        }
    }
    return Request::is($routes) ? $activeClass : $notActiveClass;
}

function reverseSlug($value)
{
    return ucwords(str_replace(['-', '_'], ' ', $value));
}

<?php /** @noinspection PhpComposerExtensionStubsInspection */

namespace common\helper;

use App\Model\HerdProfileAssessor;
use App\Model\SowReplacementAssessor;

class ReportHelper
{
    public static $highChartAPIURL = "http://export.highcharts.com/";

    public static function generateHighChartPostData($data)
    {
        $postData = [
            "async" => true,
            "asyncRendering" => false,
            "constr" => "Chart",
            "infile" => json_encode($data, JSON_NUMERIC_CHECK),
            "scale" => false,
            "styledMode" => false,
            "type" => "image/png",
            "width" => false,
        ];
        return json_encode($postData);
    }

    public static function callAPI($highChartObj)
    {
        return self::$highChartAPIURL . CURLHelper::callURL('POST', self::$highChartAPIURL, self::generateHighChartPostData($highChartObj));
    }

    public static function getCommonChartObject($title, $data, $categories)
    {
        $highChart = [
            "credits" => [
                "enabled" => false
            ],
            "legend" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "chart" => [
                "type" => 'spline',
                "backgroundColor" => '#404040'
            ],
            "title" => [
                "text" => $title,
                "style" => [
                    "color" => 'white'
                ]
            ],
            "xAxis" => [
                "labels" => [
                    "enabled" => true,
                    "style" => [
                        "color" => 'white'
                    ]
                ],
                "categories" => $categories
            ],
            "yAxis" => [
                "min" => 1,
                "max" => 3,
                "tickInterval" => 1,
                "title" => [
                    "text" => ''
                ],
                "labels" => [
                    "enabled" => true,
                    "style" => [
                        "color" => 'white'
                    ]
                ],
                "gridLineWidth" => 0,
                "plotLines" => [
                    [
                        "color" => 'rgba(192,0,0,0.50)',
                        "width" => 30,
                        "value" => 3
                    ],
                    [
                        "color" => 'rgba(244,177,131,0.50)',
                        "width" => 30,
                        "value" => 2
                    ],
                    [
                        "color" => 'rgba(146,208,80,0.50)',
                        "width" => 30,
                        "value" => 1
                    ]
                ],
                "categories" => [
                    '',
                    'NOT LIMITING',
                    'CAN BE IMPROVED',
                    'URGENT CHANGES',
                ],
            ],
            "plotOptions" => [
                "series" => [
                    "states" => [
                        "hover" => [
                            "enabled" => false,
                        ]
                    ]
                ]
            ],
            "series" => [[
                "lineWidth" => 0,
                "showInLegend" => false,
                "marker" => [
                    "symbol" => 'diamond',
                    "fillColor" => '#fff'
                ],
                "data" => $data
            ]]
        ];
        return $highChart;
    }

    public static function renderGiltAssessor($data, $categories)
    {
        return self::callAPI(self::getCommonChartObject('Gilt Assessor', $data, $categories));
    }

    public static function renderInseminationAssessor($data, $categories)
    {
        return self::callAPI(self::getCommonChartObject('Insemination Assessor', $data, $categories));
    }

    public static function renderGestationAssessor($data, $categories)
    {
        return self::callAPI(self::getCommonChartObject('Gestation Assessor', $data, $categories));
    }

    public static function renderLactationAssessor($data, $categories)
    {
        return self::callAPI(self::getCommonChartObject('Lactation Assessor', $data, $categories));
    }

    public static function getParityCommonSeriesChartObject($title, $data, $categories)
    {
        return [
            'credits' => [
                'enabled' => false
            ],
            'chart' => [
                'type' => 'column'
            ],
            'title' => [
                'text' => $title
            ],
            'xAxis' => [
                'categories' => $categories,
                'crosshair' => true
            ],
            'yAxis' => [
                'min' => 0,
                'title' => [
                    'text' => 'Percent'
                ]
            ],
            'plotOptions' => [
                'column' => [
                    'pointPadding' => 0.2,
                    'borderWidth' => 0
                ]
            ],
            'series' => $data,
            'colors' => ['#24416E', '#f45b5b', '#2b908f', '#50B432', '#90ed7d', '#64E572']
        ];
    }

    public static function renderHerdProfileAssessor($data)
    {
        return self::callAPI(self::getParityCommonSeriesChartObject('Herd Profile', $data, HerdProfileAssessor::$parityTitles));
    }

    public static function renderSowReplacementAssessor($data)
    {
        return self::callAPI(self::getParityCommonSeriesChartObject('Sow Replacement', $data, SowReplacementAssessor::$parityTitles));
    }

    public static function renderLesionTypeSeries($lesionCountSeries, $getObj = false)
    {
        $highChartObj = [
            "credits" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "chart" => [
                "plotBackgroundColor" => null,
                "plotBorderWidth" => null,
                "plotShadow" => false,
                "type" => 'pie',
            ],
            "title" => [
                "text" => "LESION PER TYPE"
            ],
            "tooltip" => [
                "pointFormat" => '<b>{point.percentage:.1f}%</b>',
            ],
            "plotOptions" => [
                "pie" => [
                    "allowPointSelect" => true,
                    "cursor" => 'pointer',
                    "dataLabels" => [
                        "enabled" => false,
                    ],
                    "showInLegend" => true,
                ],
            ],
            "series" => [
                [
                    "name" => '',
                    "colorByPoint" => true,
                    "data" => $lesionCountSeries
                ]
            ]
        ];

        if ($getObj) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

    public static function renderCountOfLesionPerParityPerType($countOfLesionPerParityPerType, $getObj)
    {
        $highChartObj = [
            "credits" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "chart" => [
                "type" => 'bar'
            ],
            "title" => [
                "text" => 'COUNT OF LESION PER SEVERITY and TYPE'
            ],
            "xAxis" => [
                "categories" => ['SEVERE', 'MODERATE', 'LIGHT']
            ],
            "yAxis" => [
                "min" => 0,
                "title" => null
            ],
            "legend" => [
                "reversed" => true
            ],
            "plotOptions" => [
                "series" => [
                    "stacking" => 'normal'
                ]
            ],
            "series" => $countOfLesionPerParityPerType
        ];

        if ($getObj) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

    public static function renderPercentPerTypeOfLesion($percentPerTypeOfLesion, $getObj)
    {
        $highChartObj = [
            "credits" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "chart" => [
                "type" => 'column'
            ],
            "title" => [
                "text" => 'PERCENT PER TYPE OF LESION'
            ],
            "subtitle" => null,
            "xAxis" => [
                "type" => 'category'
            ],
            "yAxis" => [
                "title" => [
                    "text" => ''
                ]
            ],
            "legend" => [
                "enabled" => false
            ],
            "plotOptions" => [
                "series" => [
                    "borderWidth" => 0,
                    "dataLabels" => [
                        "enabled" => true,
                        "format" => "{point.y:.0f}%"
                    ]
                ]
            ],
            "tooltip" => [
                "headerFormat" => '<span style="font-size:11px">{series.name}</span><br>',
                "pointFormat" => '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.0f}%</b> of total<br/>'
            ],
            "series" => [
                [
                    "name" => '',
                    "colorByPoint" => true,
                    "data" => $percentPerTypeOfLesion
                ]
            ]
        ];

        if ($getObj) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

    public static function renderSeverityLesionPerParity($severityLesionPerParity, $getObj)
    {
        $highChartObj = [
            "credits" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "chart" => [
                "type" => 'bar'
            ],
            "title" => [
                "text" => 'SEVERITY OF LESION PER PARITY'
            ],
            "xAxis" => [
                "categories" => ['PARITY > 6', 'PARITY 6', 'PARITY 5', "PARITY 4", 'PARITY 3', 'PARITY 2', "PARITY 1"]
            ],
            "yAxis" => [
                "min" => 0,
                "title" => null
            ],
            "legend" => [
                "reversed" => true
            ],
            "plotOptions" => [
                "series" => [
                    "stacking" => 'percent',
                    "dataLabels" => [
                        "enabled" => true,
                        "format" => '{point.y} ({point.percentage:.0f}%)'
                    ]
                ]
            ],
            "series" => $severityLesionPerParity
        ];

        if ($getObj) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

    public static function renderNumberOFEvaluatedSowPerParity($numberOFEvaluatedSowPerParity, $getObj = false)
    {
        $highChartObj = [
            "credits" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "chart" => [
                "plotBackgroundColor" => null,
                "plotBorderWidth" => null,
                "plotShadow" => false,
                "type" => 'pie',
            ],
            "title" => [
                "text" => "NUMBER OF EVALUATED SOWS PER PARITY"
            ],
            "tooltip" => [
                "pointFormat" => '<b>{point.percentage:.1f}%</b>',
            ],
            "plotOptions" => [
                "pie" => [
                    "allowPointSelect" => true,
                    "cursor" => 'pointer',
                    "dataLabels" => [
                        "enabled" => false,
                    ],
                    "showInLegend" => true,
                ],
            ],
            "series" => [
                [
                    "name" => '',
                    "colorByPoint" => true,
                    "data" => $numberOFEvaluatedSowPerParity
                ]
            ]
        ];

        if ($getObj) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

    public static function renderSeverityOfLesionsPerTypeOfLesions($severityOfLesionsPerTypeOfLesions, $getObj)
    {
        $highChartObj = [
            "credits" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "chart" => [
                "type" => 'column'
            ],
            "title" => [
                "text" => 'SEVERITY OF LESIONS PER TYPE OF LESION'
            ],
            "tooltip" => [
                "pointFormat" => '<span style="color:{series.color}">{series.name}</span>: {point.percentage:.0f}%<br/>',
                "shared" => true
            ],
            "xAxis" => [
                "categories" => ['WL', 'CRK S/H', 'CRK H', 'CRK V', 'EROSION', 'LONG DC', 'LONG CL']
            ],
            "yAxis" => [
                "min" => 0,
                "title" => [
                    "text" => '%'
                ]
            ],
            "plotOptions" => [
                "column" => [
                    "stacking" => 'percent'
                ]
            ],
            "series" => $severityOfLesionsPerTypeOfLesions
        ];

        if ($getObj) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

    public static function renderGiltBreakEvenAssessor($series, $lineOfCost, $categories, $getObject = false)
    {
        $highChartObj = [
            "chart" => [
                "type" => 'column'
            ],
            "credits" => [
                "enabled" => false
            ],
            "title" => [
                "text" => 'Gilt Break Even'
            ],
            "subtitle" => [
                "text" => 'ACCUMULATED BENEFIT PER PARITY AND SOW WEANING CAPACITY COMPARED WITH GILT BREAKEVEN LINE'
            ],
            "tooltip" => [
                "headerFormat" => '<span >{point.key}</span><table>',
                "pointFormat" => '<tr><td >{series.name}=> </td><td ><b>{point.y} €</b></td></tr>',
                "footerFormat" => '</table>',
                "shared" => true,
                "useHTML" => true
            ],
            "xAxis" => [
                "categories" => $categories,
                "crosshair" => true
            ],
            "yAxis" => [
                "min" => 0,
                "title" => [
                    "text" => '€'
                ],
                "plotLines" => [
                    [
                        "color" => 'rgba(192,0,0,0.50)',
                        "width" => 2,
                        "value" => $lineOfCost
                    ]
                ]
            ],
            "series" => $series
        ];

        if ($getObject) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

    public static function renderGiltBreakEvenAssessorImpactPerKg($series, $getObject = false)
    {
        $highChartObj = [
            "chart" => [
                "type" => 'pie'
            ],
            "credits" => [
                "enabled" => false
            ],
            "exporting" => ["enabled" => false],
            "title" => [
                "text" => 'Feed Costs'
            ],
            "tooltip" => [
                "pointFormat" => '<b>{point.percentage:.2f}%</b>',
            ],
            "plotOptions" => [
                "pie" => [
                    "allowPointSelect" => true,
                    "cursor" => 'pointer',
                    "dataLabels" => [
                        "enabled" => false,
                    ],
                    "showInLegend" => true,
                ],
            ],
            "series" => [[
                "name" => '',
                "colorByPoint" => true,
                "data" => $series
            ]]
        ];

        if ($getObject) {
            return $highChartObj;
        }

        return self::callAPI($highChartObj);
    }

}

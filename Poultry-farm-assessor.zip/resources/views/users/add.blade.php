@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-header">
                @empty($user) Add @else Edit @endempty User
            </div>
            <div class="card-body">
                <form action="{{$routeToSave}}" method="post" class="row">
                    @csrf

                    @component('components.form.input-text',[
                    'label'=>'Name',
                    'name'=>'name',
                    'value'=>setFormComponentValue($user,'name'),
                    'placeholder'=>'Enter User Name',
                    'parent_class'=>'col-md-6 form-required'
                    ])
                    @endcomponent

                    @component('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($user,'email'),
                    'placeholder'=>'Enter User Email',
                    'parent_class'=>'col-md-6 form-required'
                    ])
                    @endcomponent

                    @component('components.form.input-password',[
                    'label'=>'Password',
                    'name'=>'password',
                    'placeholder'=>'Enter User password',
                    'parent_class'=>'col-md-6 form-required'
                    ])
                    @endcomponent

                    @component('components.form.input-password',[
                    'label'=>'Confirm Password',
                    'name'=>'confirmed',
                    'placeholder'=>'Enter Confirm password',
                    'parent_class'=>'col-md-6 form-required'
                    ])
                    @endcomponent

                    @component('components.form.input-radio',[
                    'label'=>'Is Admin',
                    'name'=>'is_admin',
                    'value'=>setFormComponentValue($user,'is_admin'),
                    'class'=>'custom-control-inline',
                    'parent_class'=>'col-md-12',
                    'items'=>[['label'=>'Admin','value'=>'1'],['label'=>'User','value'=>'0']]
                    ])
                    @endcomponent

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            @empty($user) Add @else Edit @endempty User
                        </button>
                        <a href="{{route('user-list')}}" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

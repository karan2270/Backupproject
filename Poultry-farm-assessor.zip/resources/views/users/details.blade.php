@extends('layouts.app',['datatable'=>true])

@section('content')
    <div class="container">
        <div class="clearfix">
            <a href="{{route('add-user')}}" class="btn btn-primary float-right">Add User</a>
        </div>
        <div class="mt-2">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered table-sm" id="user-list"></table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('extra-js')
    <script>
        $('#user-list').dataTable({
            ajax: {
                type: 'POST',
                url: "{{ route('users-datatable')}}",
            },
            processing: true,
            serverSide: true,
            responsive: true,
            columns: [
                {data: 'id', title: 'ID'},
                {data: 'name', title: 'Name'},
                {data: 'email', title: 'Email'},
                {data: 'actions', title: 'Actions'},
            ],
        });
    </script>
@endsection

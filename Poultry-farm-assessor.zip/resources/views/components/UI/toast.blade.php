@if(\Illuminate\Support\Facades\Session::has('notify'))
    <div class="toast alert {{\Illuminate\Support\Facades\Session::get('notify-class')}} alert-dismissible shadow border fade show" role="alert">
        @if(\Illuminate\Support\Facades\Session::has('notify-title'))
            <strong>{{\Illuminate\Support\Facades\Session::get('notify-title')}}</strong>
        @endif
        {{\Illuminate\Support\Facades\Session::get('notify')}}
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
@endif

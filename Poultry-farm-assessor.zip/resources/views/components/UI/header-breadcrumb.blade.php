<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        @foreach($breadcrumbs as $breadcrumb)
            <li class="breadcrumb-item @if($breadcrumb['active']) active @endif">
                @empty($breadcrumb['link'])
                    {{$breadcrumb['title']}}
                @else
                    <a href="{{$breadcrumb['link']}}">{{$breadcrumb['title']}}</a>
                @endempty
            </li>
        @endforeach
    </ol>
</nav>

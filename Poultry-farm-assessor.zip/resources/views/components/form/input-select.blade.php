@php
    $class = isset($class) ? $class : '';
    $parent_class = isset($parent_class) ? $parent_class : '';
    $other = isset($other) ? $other : '';
    $value = isset($value) ? $value : null;
    $unselectable = isset($unselectable) ? $unselectable : false;
@endphp
<div class="form-group {{$parent_class}}">
    <label for="{{$name}}">@lang($label)</label>
    <select
        class="custom-select {{$class}} {{ $errors->has(str_replace(array('[',']'),'',$name)) ? ' is-invalid' : '' }}"
        id="{{$name}}" name="{{$name}}" {!! $other !!}>
        @if($unselectable)
            <option selected value="">@lang($unselectable)</option>
        @endif
        {{ $slot }}
    </select>
    @if ($errors->has($name))
        <span class="invalid-feedback">{{ isset($error_msg)?$error_msg:$errors->first($name) }}</span>
    @endif
</div>

@extends('layouts.app')

@section('content')
    <div class="container">
        @include('components.UI.header-breadcrumb',['breadcrumbs'=>$breadcrumbs])
        <h4>Assessors : {{$companyEvaluation->first_name}} {{$companyEvaluation->last_name}}</h4>
        <div class="clearfix my-3">
            <a href="{{route('company-evaluation-list', ['company_id' => $company_id, 'company_location_id' => $company_location->id])}}"
               class="btn btn-primary float-right">Back </a>
        </div>
        <div class="row">
            <div class="col-3">
                <div class="card">
                    <div class="card-body">
                        @if($liveBroiler)
                            <a href="{{route('company-assessor-view', ['company_id' => $company_id, 'company_location_id' => $company_location->id, 'company_evaluation_id' => $companyEvaluation->id])}}">Live
                                Broiler
                                Assessor</a>
                        @else
                            <a href="{{route('add-liveBroiler-assessor',[ 'company_id' => $company_id,  'company_location_id'=>$company_location->id ,'company_evaluation_id'=>$companyEvaluation->id])}}">Live
                                Broiler
                                Assessor</a>
                        @endif
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card">
                    <div class="card-body">

                        <a>Academy Assessor</a>

                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card">
                    <div class="card-body">

                        <a >Report Assessor</a>

                    </div>
                </div>
            </div>
        </div>

    </div>
@endsection

@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-header">
                @empty($companyEvaluationLocation) Add @else Edit @endempty Evaluation
            </div>
            <div class="card-body">
                <form action="{{$routeToSave}}" method="post" class="row">
                    @csrf
                    <input type="hidden" name="company_location_id" value="{{$companyEvaluation->id}}">
                    @component('components.form.input-text',[
                    'label'=>'First Name',
                    'name'=>'first_name',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'first_name'),
                    'placeholder'=>'Enter First name',
                    'parent_class'=>'col-md-6 form-required'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Last Name',
                    'name'=>'last_name',
                   'value'=>setFormComponentValue($companyEvaluationLocation,'last_name'),
                    'placeholder'=>'Enter Last name',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'email'),
                    'placeholder'=>'Enter Email',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Phone',
                    'name'=>'phone',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'phone'),
                    'placeholder'=>'Enter phone',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Description',
                    'name'=>'description',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'description'),
                    'placeholder'=>'Enter Description',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-date',[
                    'label'=>'Date',
                    'name'=>'date',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'date'),
                    'placeholder'=>'Enter date',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            @empty($companyEvaluationLocation) Add @else Edit @endempty Evaluation
                        </button>
                            <a href="{{route('company-evaluation-list', ['company_id' => $company->id, 'company_location_id' => $company_location->id])}}"
                               class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

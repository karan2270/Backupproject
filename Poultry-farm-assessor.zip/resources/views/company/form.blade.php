@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-header">
                @empty($company) Add @else Edit @endempty Company
            </div>
            <div class="card-body">
                <form action="{{$routeToSave}}" method="post" class="row">
                    @csrf

                    @component('components.form.input-text',[
                    'label'=>'Company Name',
                    'name'=>'company_name',
                   'value'=>setFormComponentValue($company,'company_name'),
                    'placeholder'=>'Enter Company name',
                    'parent_class'=>'col-md-6 form-required'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Contact Name',
                    'name'=>'contact_name',
                    'value'=>setFormComponentValue($company,'contact_name'),
                    'placeholder'=>'Enter Contact name',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($company,'email'),
                    'placeholder'=>'Enter Email',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Phone',
                    'name'=>'phone',
                    'value'=>setFormComponentValue($company,'phone'),
                    'placeholder'=>'Enter phone',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Address',
                    'name'=>'address',
                    'value'=>setFormComponentValue($company,'address'),
                    'placeholder'=>'Enter address',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Country',
                    'name'=>'country',
                    'value'=>setFormComponentValue($company,'country'),
                    'placeholder'=>'Enter Country',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            @empty($company) Add @else Edit @endempty Company
                        </button>
                        <a href="{{route('home')}}" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

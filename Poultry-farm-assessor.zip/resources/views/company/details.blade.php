@extends('layouts.app',['datatable'=>true])

@section('content')
    <div class="container">
        @include('components.UI.header-breadcrumb',['breadcrumbs'=>$breadcrumbs])
        <div>
            <h3>{{$company->company_name}}</h3>
        </div>
        <div class="clearfix text-right">
            <a href="{{ route('home') }}"
               class="btn btn-success">
                Back
            </a>
            <a href="{{route('add-Company-location',['company_id' => $company->id])}}"
               class="btn btn-primary">
                Add Company Location
            </a>
        </div>
        <div class="mt-2">
            <div class="row">
                @foreach($company->companyLocation as $companyLocation)
                    <div class="col-md-4 col-lg-3 col-sm-6 ">
                        <div class="card">
                            <div class="card-body">
                                <h4>{{$companyLocation->name_location}}</h4>
                                <span class="badge badge-info">{{$companyLocation->type_location}}</span>
                                <div class="dropdown top-right-corner">
                                    <span class="fa fa-ellipsis-v p-3 cursor-pointer"
                                          data-toggle="dropdown" aria-haspopup="true"
                                          aria-expanded="false">
                                    </span>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item"
                                           href={{ route('Company-location-edit', ['company_id' => $companyLocation->company_id, 'company_location_id' => $companyLocation->id]) }}>Edit</a>

                                        <a class="dropdown-item" href="#"
                                           onclick="confirmDelete('delete-company-location-form-{{$companyLocation->id}}',event)">
                                            Delete
                                        </a>

                                        <form id="delete-company-location-form-{{$companyLocation->id}}"
                                              action="{{ route('delete-company-location', ['company_id' => $companyLocation->company_id, 'company_location_id' => $companyLocation->id]) }}"
                                              method="POST" class="d-none">
                                            @csrf
                                            @method('DELETE')
                                        </form>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <a class="btn btn-primary"
                                       href={{route('company-evaluation-list', [ 'company_id' => $companyLocation->company_id ,'company_location_id' => $companyLocation->id]) }}>
                                        <i class="fa fa-long-arrow-alt-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>
@endsection

@section('extra-js')
    <script>
        function confirmDelete(formId, e) {
            const confirmation = confirm("Are you sure?");
            if (confirmation) {
                e.preventDefault();
                document.getElementById(formId).submit();
            }
        }
    </script>
@endsection


@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="card">
            <div class="card-header">
                @empty($companyLocation) Add @else Edit @endempty Company Location
            </div>
            <div class="card-body">
                <form action="{{$routeToSave}}" method="post" class="row">
                    @csrf
                    <input type="hidden" name="company_id" value="{{$company->id}}">

                    @component('components.form.input-select',[
                    'label'=>'Type of Location',
                    'name'=>'type_location',
                    'value'=>setFormComponentValue($companyLocation,'type_location'),
                    'parent_class'=>'col-md-6 form-required'
                    ])
                        <option value="farm">Farm</option>
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Name Location',
                    'name'=>'name_location',
                    'value'=>setFormComponentValue($companyLocation,'name_location'),
                    'placeholder'=>'Enter Location',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($companyLocation,'email'),
                    'placeholder'=>'Enter email',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Phone',
                    'name'=>'phone',
                    'value'=>setFormComponentValue($companyLocation,'phone'),
                    'placeholder'=>'Enter phone',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Address',
                    'name'=>'address',
                    'value'=>setFormComponentValue($companyLocation,'address'),
                    'placeholder'=>'Enter address',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Contact name',
                    'name'=>'contact_name',
                    'value'=>setFormComponentValue($companyLocation,'contact_name'),
                    'placeholder'=>'Enter Contact Name',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    @component('components.form.input-text',[
                    'label'=>'Country ',
                    'name'=>'country',
                    'value'=>setFormComponentValue($companyLocation,'country'),
                    'placeholder'=>'Enter Country',
                    'parent_class'=>'col-md-6'
                    ])
                    @endcomponent

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            @empty($companyLocation) Add @else Edit @endempty Company Location
                        </button>
                               <a href="{{route('company-location-list',['company_id'=>$company['id']])}}" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

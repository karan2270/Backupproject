
@extends('layouts.app')
@section('content')
    <div class="container">
        @include('components.UI.header-breadcrumb',['breadcrumbs'=>$breadcrumbs])

        <h3>View Assessor {{$liveBroilerData['company_evaluation_id']}}</h3>

        <div class="clearfix my-3">
            <div class="float-right">

                <a href="{{route('company-assessor-list',[ 'company_id' => $company->id, 'company_location_id' => $company_location->id,'company_evaluation_id'=>$liveBroilerData['company_evaluation_id']])}}"
                   class="btn btn-primary">Back </a>
                <a href="{{route('edit-live-broiler',[ 'company_id' => $company->id, 'company_location_id' => $company_location->id,'company_evaluation_id'=>$liveBroilerData['company_evaluation_id'],'company_assessor_id'=>$liveBroilerData['id']])}}"
                   class="btn btn-primary">Edit </a>
            </div>
        </div>


        <div class="card">
            <div class="card-body">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-information-tab" data-toggle="tab"
                           href="#INFORMATION"
                           role="tab" aria-controls="nav-information" aria-selected="true">INFORMATION</a>

                        <a class="nav-item nav-link" id="nav-Broiler-tab" data-toggle="tab" href="#nav-Broiler"
                           role="tab" aria-controls="nav-Broiler" aria-selected="false">BROILER</a>

                        <a class="nav-item nav-link" id="nav-feed-tab" data-toggle="tab" href="#nav-feed"
                           role="tab" aria-controls="nav-feed" aria-selected="false">FEED</a>

                        <a class="nav-item nav-link" id="nav-load-tab" data-toggle="tab" href="#nav-load"
                           role="tab" aria-controls="nav-load" aria-selected="false">LOAD</a>

                        <a class="nav-item nav-link" id="nav-minerals-tab" data-toggle="tab" href="#nav-minerals"
                           role="tab" aria-controls="nav-minerals" aria-selected="false">MINERALS</a>

                        <a class="nav-item nav-link" id="nav-Roi-tab" data-toggle="tab" href="#nav-Roi"
                           role="tab" aria-controls="nav-Roi" aria-selected="false">ROI</a>

                    </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="INFORMATION" role="tabpanel"
                         aria-labelledby="nav-information-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Trial Group</th>
                                <td>{{$liveBroilerData['trial_group']}}</td>
                            </tr>
                            <tr>
                                <th>House</th>
                                <td>{{$liveBroilerData['house']}}</td>
                            </tr>
                            <tr>
                                <th>Genetic</th>
                                <td>{{$liveBroilerData['genetic']}}</td>
                            </tr>
                            <tr>
                                <th>Number Animals</th>
                                <td>{{$liveBroilerData['number_animals']}}</td>
                            </tr>
                            <tr>
                                <th>Breeders Age</th>
                                <td>{{$liveBroilerData['breeders_age']}}</td>
                            </tr>
                            <tr>
                                <th>Chick Weight</th>

                                <td>{{$liveBroilerData['chick_weight']}}</td>
                            </tr>
                            <tr>
                                <th>Final Weight</th>
                                <td>{{$liveBroilerData['final_weight']}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-Broiler" role="tabpanel" aria-labelledby="nav-Broiler-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Date Of Entry</th>
                                <td>{{$liveBroilerData['date_of_entry']}}</td>
                            </tr>
                            <tr>
                                <th>Mortality</th>
                                <td>{{$liveBroilerData['mortality']}}</td>
                            </tr>
                            <tr>
                                <th>Culling</th>
                                <td>{{$liveBroilerData['culling']}}</td>
                            </tr>
                            <tr>
                                <th>Sex</th>
                                <td>{{$liveBroilerData['hatched']}}</td>
                            </tr>
                            <tr>
                                <th>Date Harvest</th>
                                <td>{{$liveBroilerData['date_harvest']}}</td>
                            </tr>
                            <tr>
                                <th>Thinning</th>
                                <td>{{$liveBroilerData['thinning']}}</td>
                            </tr>
                            <tr>
                                <th>Thinning Number Animals</th>
                                <td>{{$liveBroilerData['thinning_number_animals']}}</td>
                            </tr>
                            <tr>
                                <th>Thinning Weight</th>
                                <td>{{$liveBroilerData['thinning_weight']}}</td>
                            </tr>
                            <tr>
                                <th>Market Price</th>
                                <td>{{$liveBroilerData['market_price']}}</td>
                            </tr>
                            <tr>
                                <th>Growing Period</th>
                                <td>{{$liveBroilerData['growing_period']}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-feed" role="tabpanel" aria-labelledby="nav-feed-tab">
                        <table class="table table-striped">
                            <tbody>

                            <tr>
                                <th>Feed Name 1</th>
                                <td>{{$liveBroilerData['feed_name_1']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 1</th>
                                <td>{{$liveBroilerData['feed_consumption_1']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Cost 1</th>
                                <td>{{$liveBroilerData['feed_cost_1']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Name 2</th>
                                <td>{{$liveBroilerData['feed_name_2']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 2</th>
                                <td>{{$liveBroilerData['feed_consumption_2']}}</td>
                            </tr>
                            <tr>
                                <th>Feed cost 2</th>
                                <td>{{$liveBroilerData['feed_cost_2']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Name 3</th>
                                <td>{{$liveBroilerData['feed_name_3']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 3</th>
                                <td>{{$liveBroilerData['feed_consumption_3']}}</td>
                            </tr>
                            <tr>
                                <th>Feed cost 3</th>
                                <td>{{$liveBroilerData['feed_cost_3']}}</td>
                            </tr>
                            <tr>
                                <th>Fedd Name 4</th>
                                <td>{{$liveBroilerData['feed_name_4']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 4</th>
                                <td>{{$liveBroilerData['feed_consumption_4']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Cost 4</th>
                                <td>{{$liveBroilerData['feed_cost_4']}}</td>
                            </tr>
                            <tr>
                                <th>Feed Withdrawal</th>
                                <td>{{$liveBroilerData['feed_withdrawal']}}</td>
                            </tr>
                            <tr>
                                <th>Total Consumption Feed</th>
                                <td>{{$liveBroilerData['total_consumption__feed']}}</td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-load" role="tabpanel" aria-labelledby="nav-load-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Truck weight Farm exit</th>
                                <td>{{$liveBroilerData['truck_weight_farm_exit']}}</td>
                            </tr>
                            <tr>
                                <th>Truck weight abattoir arrival</th>
                                <td>{{$liveBroilerData['truck_weight_abattoir_arrival']}}</td>
                            </tr>
                            <tr>
                                <th>Trasport weight loss</th>
                                <td>{{$liveBroilerData['transport_weight_loss'] }}</td>
                            </tr>
                            <tr>
                                <th>Deads on arrival</th>
                                <td>{{$liveBroilerData['deads_on_arrival']}}</td>

                            </tr>
                            <tr>
                                <th>Liveability</th>
                                <td>{{ $liveBroilerData['liveability']}}</td>

                            </tr>
                            <tr>

                                <th>Live birds for abattoir</th>
                                <td>{{ $liveBroilerData['live birds for abattoir']}}</td>

                            </tr>
                            <tr>
                                <th>FCR</th>
                                <td>{{ $liveBroilerData['FCR']}}</td>

                            </tr>
                            <tr>
                                <th>Mortality and culling</th>
                                <td>{{ $liveBroilerData['Mortality and culling']}}</td>

                            </tr>
                            <tr>
                                <th>Adjusted FCR</th>
                                <td>{{ $liveBroilerData['Adjusted FCR']}}</td>

                            </tr>
                            <tr>
                                <th>Average Daily Gain</th>
                                <td>{{$liveBroilerData['Average Daily Gain']}}</td>

                            </tr>
                            <tr>
                                <th>Average Daily feed Intake</th>
                                <td>{{ $liveBroilerData['Average Daily Feed Intake']}}</td>

                            </tr>
                            <tr>
                                <th>Total Feed Cost per bird</th>
                                <td>{{  $liveBroilerData['Total Feed Cost per bird']}}</td>

                            </tr>
                            <tr>
                                <th>Avg Feed Cost</th>
                                <td>{{    $liveBroilerData['Avg Feed Cost']}}</td>

                            </tr>
                            <tr>
                                <th>Cost of availa Inclusion</th>
                                <td>{{  $liveBroilerData['Cost Of Availa Inclusion']}}</td>

                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-minerals" role="tabpanel" aria-labelledby="nav-minerals-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Zinc</th>
                                <td>{{$liveBroilerData['zinc']}}</td>
                            </tr>
                            <tr>
                                <th>Aaila Zinc</th>
                                <td>{{$liveBroilerData['availa_zinc']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Zinc Concentration</th>
                                <td>{{$liveBroilerData['availa_zinc_concentration']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Zinc Cost</th>
                                <td>{{$liveBroilerData['availa_zinc_cost']}}</td>
                            </tr>
                            <tr>
                                <th>Manganese</th>
                                <td>{{$liveBroilerData['manganese']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Manganese</th>
                                <td>{{$liveBroilerData['availa_manganese']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Manganese Concentration</th>
                                <td>{{$liveBroilerData['availa_manganese_concentration']}}</td>
                            </tr>
                            <tr>
                                <th>Avail Maanganese Cost</th>
                                <td>{{$liveBroilerData['avail_maanganese_cost']}}</td>
                            </tr>
                            <tr>
                                <th>Iron</th>
                                <td>{{$liveBroilerData['iron']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Iron</th>
                                <td>{{$liveBroilerData['availa_iron']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Iron Concentration</th>
                                <td>{{$liveBroilerData['availa_iron_concentration']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Iron Cost</th>
                                <td>{{$liveBroilerData['availa_iron_cost']}}</td>
                            </tr>
                            <tr>
                                <th>Copper</th>
                                <td>{{$liveBroilerData['copper']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Copper</th>
                                <td>{{$liveBroilerData['availa_copper']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Copper Concentration</th>
                                <td>{{$liveBroilerData['availa_copper_concentration']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Copper Cost</th>
                                <td>{{$liveBroilerData['availa_copper_cost']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Chromium</th>
                                <td>{{$liveBroilerData['availa_chromium']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Chromium Concentration</th>
                                <td>{{$liveBroilerData['availa_chromium_concentration']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Chromium Cost</th>
                                <td>{{$liveBroilerData['availa_chromium_cost']}}</td>
                            </tr>
                            <tr>
                                <th>Selenium</th>
                                <td>{{$liveBroilerData['selenium']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Selenium</th>
                                <td>{{$liveBroilerData['availa_selenium']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Selenium Concentration</th>
                                <td>{{$liveBroilerData['availa_selenium_concentration']}}</td>
                            </tr>
                            <tr>
                                <th>Availa Selenium Cost</th>
                                <td>{{$liveBroilerData['availa_selenium_cost']}}</td>


                            </tr>
                            <tr>
                                <th>Cost of Availa Inclusion</th>
                                <td>{{$liveBroilerData['Cost Of Availa Inclusion'] }}</td>


                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-Roi" role="tabpanel" aria-labelledby="nav-Roi-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Value Of Sale</th>
                                <td>{{$liveBroilerData['Value of Sale']}}</td>
                            </tr>
                            <tr>
                                <th>Income</th>
                                <td>{{$liveBroilerData['Income']}}</td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

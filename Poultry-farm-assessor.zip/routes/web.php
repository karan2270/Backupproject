<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('company/add', 'CompanyController@addCompany')->name('add-company');

Auth::routes(['register' => false]);

Route::get('/home', 'HomeController@index')->name('home');

Route::post('/save-company', 'CompanyController@saveCompany')->name('save-company');
Route::post('company-datatable', 'CompanyController@companyDetails')->name('company-datatable');
Route::get('/company/edit/{company_id}', 'CompanyController@editCompany')->name('edit-company');
Route::post('/company/update/{company_id}', 'CompanyController@updateCompany')->name('update-company');
Route::delete('/company/delete/{company_id}', 'CompanyController@deleteCompany')->name('delete-company');


Route::group(['middleware' => ['admin']], function () {
    Route::get('/users', 'UserController@userList')->name('user-list');
    Route::get('/user/add', 'UserController@addUser')->name('add-user');
    Route::post('/user/save', 'UserController@saveUser')->name('save-user');
    Route::post('/users/datatable', 'UserController@datatable')->name('users-datatable');
    Route::get('/user/edit/{user_id}', 'UserController@editUser')->name('edit-user');
    Route::post('/user/update/{user_id}', 'UserController@updateUser')->name('update-user');
    Route::delete('/user/delete/{user_id}', 'UserController@deleteUser')->name('delete-user');
});


Route::group(['prefix' => 'company-location/{company_id}'], function () {
    Route::get('/', 'CompanyController@locationList')->name('company-location-list');
    Route::get('/add', 'CompanyLocationController@addCompanyLocation')->name('add-Company-location');
    Route::post('/save', 'CompanyLocationController@saveCompanyLocation')->name('save-company-location');
    Route::post('/datatable', 'CompanyLocationController@datatable')->name('company-location-datatable');
    Route::get('/edit/{company_location_id}', 'CompanyLocationController@editCompanyLocation')->name('Company-location-edit');
    Route::post('/update/{company_location_id}', 'CompanyLocationController@updateCompanyLocation')->name('update-company-location');
    Route::delete('/delete/{company_location_id}', 'CompanyLocationController@deleteCompanyLocation')->name('delete-company-location');
});

Route::group(['prefix' => 'company-evaluation/{company_id}/{company_location_id}'], function () {
    Route::get('/', 'CompanyLocationController@evaluationList')->name('company-evaluation-list');
    Route::post('/datatable', 'CompanyEvaluationController@datatable')->name('company-evaluation-datatable');
    Route::get('/add', 'CompanyEvaluationController@addCompanyEvaluation')->name('add-company-evaluation');
    Route::post('/save', 'CompanyEvaluationController@saveCompanyEvaluation')->name('save-company-evaluation');
    Route::get('/edit/{company_evaluation_id}', 'CompanyEvaluationController@editCompanyEvaluation')->name('Company-evaluation-edit');
    Route::post('/update/{company_evaluation_id}', 'CompanyEvaluationController@updateCompanyEvaluation')->name('update-company-evaluation');
    Route::delete('/delete/{company_evaluation_id}', 'CompanyEvaluationController@deleteCompanyEvaluation')->name('delete-company-evaluation');
});


// todo change assessor routes
Route::group(['prefix' => 'assessor-list/{company_id}/{company_location_id}/{company_evaluation_id}'], function () {
    Route::get('/', 'CompanyEvaluationController@assessorList')->name('company-assessor-list');
    Route::get('/add', 'LiveBroilerController@addAssessor')->name('add-liveBroiler-assessor');
    Route::post('/save', 'LiveBroilerController@saveAssessor')->name('save-assessor-live-broiler');
    Route::get('/view', 'LiveBroilerController@viewAssessor')->name('company-assessor-view');
    Route::get('/edit/{company_assessor_id}', 'LiveBroilerController@editAssessor')->name('edit-live-broiler');
    Route::post('/update/{company_assessor_id}', 'LiveBroilerController@updateAssessor')->name('update-assessor-liveBroiler');
});

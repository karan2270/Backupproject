<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('components.UI.header-breadcrumb',['breadcrumbs'=>$breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <h3><?php echo e($companyEvaluation->name_location); ?></h3>
        </div>
        <div class="clearfix text-right">
            <a href="<?php echo e(route('company-location-list', ['company_id' => $companyEvaluation->company_id])); ?>"
               class="btn btn-success">
                Back
            </a>
            <a href="<?php echo e(route('add-company-evaluation',['company_id'  => $companyEvaluation->company_id ,'company_location_id' => $companyEvaluation->id])); ?>"
               class="btn btn-primary">
                Add Company Evaluation
            </a>
        </div>

        <div class="mt-2">
            <div class="row">
                <?php $__currentLoopData = $companyEvaluation->companyEvaluation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companyEvaluationDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-lg-3 col-sm-6 ">
                        <div class="card">
                            <div class="card-body">
                                <h4><?php echo e($companyEvaluationDetails->first_name); ?></h4>
                                <span class="badge badge-info"><?php echo e($companyEvaluationDetails->date); ?></span>
                                <div class="dropdown top-right-corner">
                                    <span class="fa fa-ellipsis-v p-3 cursor-pointer"
                                          data-toggle="dropdown" aria-haspopup="true"
                                          aria-expanded="false">
                                    </span>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">

                                        <a class="dropdown-item"
                                           href=<?php echo e(route('Company-evaluation-edit', ['company_id' => $companyId, 'company_location_id' => $companyLocationId, 'company_evaluation_id' => $companyEvaluationDetails->id])); ?>>Edit
                                        </a>

                                        <a class="dropdown-item" href="#"
                                           onclick="confirmDelete('delete-company-location-form-<?php echo e($companyEvaluationDetails->id); ?>',event)">
                                            Delete
                                        </a>

                                        <form id="delete-company-location-form-<?php echo e($companyEvaluationDetails->id); ?>"
                                              action="<?php echo e(route('delete-company-evaluation', ['company_id' => $companyId,  'company_location_id' => $companyLocationId, 'company_evaluation_id' => $companyEvaluationDetails->id])); ?>"
                                              method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <a class="btn btn-primary"
                                       href=<?php echo e(route('company-assessor-list', ['company_id' => $companyId,  'company_location_id' => $companyLocationId,'company_evaluation_id' => $companyEvaluationDetails->id])); ?>>
                                        <i class="fa fa-long-arrow-alt-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        function confirmDelete(formId, e) {
            const confirmation = confirm("Are you sure?");
            if (confirmation) {
                e.preventDefault();
                document.getElementById(formId).submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app',['datatable'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/company-location/details.blade.php ENDPATH**/ ?>
<?php
    $class = isset($class) ? $class : '';
    $parent_class = isset($parent_class) ? $parent_class : '';
    $other = isset($other) ? $other : '';
?>
<div class="form-group <?php echo e($parent_class); ?>">
    <label class="d-block"><?php echo e($label); ?></label>
    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-check form-check-inline <?php echo e($class); ?> ">
            <input type="radio" id="<?php echo e($name.'_'.$index); ?>"
                   name="<?php echo e($name); ?>" value="<?php echo e($item['value']); ?>"
                   class="form-check-input <?php echo e($errors->has($name) ? ' is-invalid' : ''); ?>"
                   <?php if($value==$item['value']): ?> checked="checked" <?php endif; ?> <?php echo e($other); ?>>
            <label class="form-check-label" for="<?php echo e($name.'_'.$index); ?>"><?php echo e($item['label']); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($errors->has($name)): ?>
        <span class="invalid-feedback d-block"><?php echo e(isset($error_msg)?$error_msg:$errors->first($name)); ?></span>
    <?php endif; ?>
</div>
<?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/components/form/input-radio.blade.php ENDPATH**/ ?>
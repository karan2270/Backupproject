<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <?php if(empty($company)): ?> Add <?php else: ?> Edit <?php endif; ?> Company
            </div>
            <div class="card-body">
                <form action="<?php echo e($routeToSave); ?>" method="post" class="row">
                    <?php echo csrf_field(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Company Name',
                    'name'=>'company_name',
                   'value'=>setFormComponentValue($company,'company_name'),
                    'placeholder'=>'Enter Company name',
                    'parent_class'=>'col-md-6 form-required'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Contact Name',
                    'name'=>'contact_name',
                    'value'=>setFormComponentValue($company,'contact_name'),
                    'placeholder'=>'Enter Contact name',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($company,'email'),
                    'placeholder'=>'Enter Email',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Phone',
                    'name'=>'phone',
                    'value'=>setFormComponentValue($company,'phone'),
                    'placeholder'=>'Enter phone',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Address',
                    'name'=>'address',
                    'value'=>setFormComponentValue($company,'address'),
                    'placeholder'=>'Enter address',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Country',
                    'name'=>'country',
                    'value'=>setFormComponentValue($company,'country'),
                    'placeholder'=>'Enter Country',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <?php if(empty($company)): ?> Add <?php else: ?> Edit <?php endif; ?> Company
                        </button>
                        <a href="<?php echo e(route('home')); ?>" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/company/form.blade.php ENDPATH**/ ?>
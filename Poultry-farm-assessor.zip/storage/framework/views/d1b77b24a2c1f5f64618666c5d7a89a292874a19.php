<?php if(\Illuminate\Support\Facades\Session::has('notify')): ?>
    <div class="toast alert <?php echo e(\Illuminate\Support\Facades\Session::get('notify-class')); ?> alert-dismissible shadow border fade show" role="alert">
        <?php if(\Illuminate\Support\Facades\Session::has('notify-title')): ?>
            <strong><?php echo e(\Illuminate\Support\Facades\Session::get('notify-title')); ?></strong>
        <?php endif; ?>
        <?php echo e(\Illuminate\Support\Facades\Session::get('notify')); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/components/UI/toast.blade.php ENDPATH**/ ?>
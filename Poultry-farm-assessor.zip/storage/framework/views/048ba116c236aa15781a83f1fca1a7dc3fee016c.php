<?php $__env->startSection('content'); ?>
    <div class="container">
        <h4>Assessors <?php echo e($companyAssessorList->id); ?></h4>
        <div class="clearfix my-3">
            <a href="<?php echo e(route('company-evaluation-list', ['company_id' => $company, 'company_location_id' => $company_location->id])); ?>"
               class="btn btn-primary float-right">Back </a>
        </div>
        <div class="row">
            <div class="col-3">
                <div class="card">
                    <div class="card-body">
                        <?php if($liveBroiler): ?>
                            <a href="<?php echo e(route('company-assessor-view', ['company_id' => $company, 'company_location_id' => $company_location->id, 'company_evaluation_id' => $companyAssessorList->id])); ?>">Live
                                Broiler
                                Assessor</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('add-liveBroiler-assessor',[ 'company_id' => $company,  'company_location_id'=>$company_location->id ,'company_evaluation_id'=>$companyAssessorList->id])); ?>">Live
                                Broiler
                                Assessor</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card">
                    <div class="card-body">

                        <a href="">Academy Assessor</a>

                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card">
                    <div class="card-body">

                        <a href="">Report Assessor</a>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/assessor/details.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <?php if(empty($companyEvaluationLocation)): ?> Add <?php else: ?> Edit <?php endif; ?> Evaluation
            </div>
            <div class="card-body">
                <form action="<?php echo e($routeToSave); ?>" method="post" class="row">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="company_location_id" value="<?php echo e($companyEvaluation->id); ?>">
                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'First Name',
                    'name'=>'first_name',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'first_name'),
                    'placeholder'=>'Enter First name',
                    'parent_class'=>'col-md-6 form-required'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Last Name',
                    'name'=>'last_name',
                   'value'=>setFormComponentValue($companyEvaluationLocation,'last_name'),
                    'placeholder'=>'Enter Last name',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'email'),
                    'placeholder'=>'Enter Email',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Phone',
                    'name'=>'phone',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'phone'),
                    'placeholder'=>'Enter phone',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Description',
                    'name'=>'description',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'description'),
                    'placeholder'=>'Enter Description',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-date',[
                    'label'=>'Date',
                    'name'=>'date',
                    'value'=>setFormComponentValue($companyEvaluationLocation,'date'),
                    'placeholder'=>'Enter date',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>
                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <?php if(empty($companyEvaluationLocation)): ?> Add <?php else: ?> Edit <?php endif; ?> Evaluation
                        </button>
                            <a href="<?php echo e(route('company-evaluation-list', ['company_id' => $company->id, 'company_location_id' => $company_location->id])); ?>"
                               class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/company-evaluation/form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('extra-css'); ?>
    <style>
        .accordion > .card .card-header {
            margin-bottom: initial;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <h2><?php if(empty($companyAssessor)): ?> Add <?php else: ?> Edit <?php endif; ?> Assessor</h2>
        <form action="<?php echo e($routeToSave); ?>" method="POST" class="accordion" id="assessor-live-broiler-form">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="company_evaluation_id" value="<?php echo e($companyEvaluation->id); ?>">

            <div class="card">
                <div class="card-header p-2" id="information-section-header">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse"
                                data-target="#information-section">
                            Information
                        </button>
                    </h2>
                </div>
                <div id="information-section" class="collapse show" data-parent="#assessor-live-broiler-form">
                    <div class="card-body">
                        <div class="row">

                            <input type="hidden" name="company_location_id" value="<?php echo e($companyEvaluation->id); ?>">
                            <?php $__env->startComponent('components.form.input-select',[
                            'label'=>'Trial Group',
                            'name'=>'trial_group',
                            'value'=>setFormComponentValue($companyAssessor,'trial_group'),
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                                <option>Control</option>
                                <option>Zinpro</option>
                                <option>C</option>
                                <option>D</option>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-text',[
                            'label'=>'HOUSE',
                            'name'=>'house',
                           'value'=>setFormComponentValue($companyAssessor,'house'),
                            'placeholder'=>'Enter House',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-select',[
                            'label'=>'Genetic',
                            'name'=>'genetic',
                            'value'=>setFormComponentValue($companyAssessor,'genetic'),
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                                <option>Ross 308</option>
                                <option>Ross 708</option>
                                <option>Cobb 500</option>
                                <option>Cobb 700</option>
                                <option>Hubbard</option>
                                <option>Arbor Acres</option>
                                <option>Indian River</option>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Number of animals ',
                            'name'=>'number_animals',
                            'value'=>setFormComponentValue($companyAssessor,'number_animals'),
                            'placeholder'=>'Enter Number of animals',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Breeders Age',
                            'name'=>'breeders_age',
                            'value'=>setFormComponentValue($companyAssessor,'breeders_age'),
                            'placeholder'=>'Enter Breeders Age',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Chick weight',
                            'name'=>'chick_weight',
                            'value'=>setFormComponentValue($companyAssessor,'chick_weight'),
                            'placeholder'=>'Enter chick weight',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Final weight',
                            'name'=>'final_weight',
                            'value'=>setFormComponentValue($companyAssessor,'final_weight'),
                            'placeholder'=>'Enter Final weight',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </div>
                    </div>
                </div>

                <div class="card-header p-2" id="broiler-section-header">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse"
                                data-target="#broiler-section">
                            Broiler
                        </button>
                    </h2>
                </div>
                <div id="broiler-section" class="collapse" data-parent="#assessor-live-broiler-form">
                    <div class="card-body">
                        <div class="row">
                            <input type="hidden" name="company_location_id" value="<?php echo e($companyEvaluation->id); ?>">
                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Mortality',
                            'name'=>'mortality',
                            'value'=>setFormComponentValue($companyAssessor,'mortality'),
                            'placeholder'=>'Enter Mortality',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Culling',
                            'name'=>'culling',
                           'value'=>setFormComponentValue($companyAssessor,'culling'),
                            'placeholder'=>'Enter Culling',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-select',[
                            'label'=>'Sex(At Hatched,Female,Male)',
                            'name'=>'hatched',
                            'value'=>setFormComponentValue($companyAssessor,'hatched'),

                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                                <option>AH</option>
                                <option>F</option>
                                <option>M</option>
                            <?php echo $__env->renderComponent(); ?>



                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Date Of Harvest',
                            'name'=>'date_harvest',
                            'value'=>setFormComponentValue($companyAssessor,'date_harvest'),
                            'placeholder'=>'Enter Date of harvest',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-select',[
                            'label'=>'Thinning',
                            'name'=>'thinning',
                            'value'=>setFormComponentValue($companyAssessor,'thinning'),
                            'parent_class'=>'col-md-6'
                            ]); ?>
                                <option>Yes</option>
                                <option>No</option>
                            <?php echo $__env->renderComponent(); ?>


                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Thinning Number Of Animals',
                            'name'=>'thinning_number_animals',
                            'value'=>setFormComponentValue($companyAssessor,'thinning_number_animals'),
                            'placeholder'=>'EnterThinking Number Of Animals',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>


                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Thinning  Weight',
                            'name'=>'thinning_weight',
                            'value'=>setFormComponentValue($companyAssessor,'thinning_weight'),
                            'placeholder'=>'Enter Thinning Weight',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>


                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Market Price',
                            'name'=>'market_price',
                            'value'=>setFormComponentValue($companyAssessor,'market_price'),
                            'placeholder'=>'Enter Market Price',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Growing period',
                            'name'=>'growing_period',
                            'value'=>setFormComponentValue($companyAssessor,'growing_period'),
                            'placeholder'=>'Enter Growing Period',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                        </div>
                    </div>
                </div>

                <div class="card-header p-2" id="feed-section-header">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse"
                                data-target="#feed-section">
                            Feed
                        </button>
                    </h2>
                </div>
                <div id="feed-section" class="collapse" data-parent="#assessor-live-broiler-form">
                    <div class="card-body">
                        <div class="row">
                            <input type="hidden" name="company_location_id" value="<?php echo e($companyEvaluation->id); ?>">
                            <?php $__env->startComponent('components.form.input-text',[
                            'label'=>'Feed Name 1',
                            'name'=>'feed_name_1',
                            'value'=>setFormComponentValue($companyAssessor,'feed_name_1'),
                            'placeholder'=>'Enter Feed Name 1 Eg.Prestarter',
                            'parent_class'=>'col-md-6 '
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Consumption 1',
                            'name'=>'feed_consumption_1',
                            'value'=>setFormComponentValue($companyAssessor,'feed_consumption_1'),
                            'placeholder'=>'Enter Feed Consumption',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Cost 1',
                            'name'=>'feed_cost_1',
                            'value'=>setFormComponentValue($companyAssessor,'feed_cost_1'),
                            'placeholder'=>'Enter Feed Cost',
                            'parent_class'=>'col-md-6'
                            ]); ?>

                            <?php echo $__env->renderComponent(); ?>


                            <?php $__env->startComponent('components.form.input-text',[
                            'label'=>'Feed Name 2',
                            'name'=>'feed_name_2',
                            'value'=>setFormComponentValue($companyAssessor,'feed_name_2'),
                             'placeholder'=>'Enter Feed Name 2 Eg.Starter',
                             'parent_class'=>'col-md-6 '
                             ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Consumption 2',
                            'name'=>'feed_consumption_2',
                            'value'=>setFormComponentValue($companyAssessor,'feed_consumption_2'),
                            'placeholder'=>'Enter Feed Consumption',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Cost 2',
                            'name'=>'feed_cost_2',
                            'value'=>setFormComponentValue($companyAssessor,'feed_cost_2'),
                            'placeholder'=>'Enter Feed Cost',
                            'parent_class'=>'col-md-6'
                            ]); ?>

                            <?php echo $__env->renderComponent(); ?>


                            <?php $__env->startComponent('components.form.input-text',[
                            'label'=>'Feed Name 3',
                            'name'=>'feed_name_3',
                            'value'=>setFormComponentValue($companyAssessor,'feed_name_3'),
                            'placeholder'=>'Enter Feed Name 3 Eg.Grower',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Consumption 3',
                            'name'=>'feed_consumption_3',
                           'value'=>setFormComponentValue($companyAssessor,'feed_consumption_3'),
                            'placeholder'=>'Enter Feed Consumption',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Cost 3',
                            'name'=>'feed_cost_3',
                            'value'=>setFormComponentValue($companyAssessor,'feed_cost_3'),
                            'placeholder'=>'Enter Feed Cost',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-text',[
                            'label'=>'Feed Name 4',
                            'name'=>'feed_name_4',
                            'value'=>setFormComponentValue($companyAssessor,'feed_name_4'),
                            'placeholder'=>'Enter Feed Name 4 Eg.Finisher',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Consumption 4',
                            'name'=>'feed_consumption_4',
                           'value'=>setFormComponentValue($companyAssessor,'feed_consumption_4'),
                            'placeholder'=>'Enter Feed Consumption',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Cost 4',
                            'name'=>'feed_cost_4',
                            'value'=>setFormComponentValue($companyAssessor,'feed_cost_4'),
                            'placeholder'=>'Enter Feed Cost',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>


                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Feed Withdrawal',
                            'name'=>'feed_withdrawal',
                            'value'=>setFormComponentValue($companyAssessor,'feed_withdrawal'),
                            'placeholder'=>'Enter Feed Withdrawal',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Total Consumption of Feed',
                            'name'=>'total_consumption__feed',
                            'value'=>setFormComponentValue($companyAssessor,'total_consumption__feed'),
                            'placeholder'=>'Enter Total Consumption of Feed',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>


                        </div>
                    </div>
                </div>

                <div class="card-header p-2" id="load-section-header">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse"
                                data-target="#load-section">
                            Load
                        </button>
                    </h2>
                </div>
                <div id="load-section" class="collapse" data-parent="#assessor-live-broiler-form">
                    <div class="card-body">
                        <div class="row">
                            <input type="hidden" name="company_location_id" value="<?php echo e($companyEvaluation->id); ?>">
                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Truck Weight Farm Exit',
                            'name'=>'truck_weight_farm_exit',
                            'value'=>setFormComponentValue($companyAssessor,'truck_weight_farm_exit'),
                            'placeholder'=>'Enter Truck Weight Farm Exit',
                            'parent_class'=>'col-md-6 '
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Truck Weight Abattoir Arrival',
                            'name'=>'truck_weight_abattoir_arrival',
                           'value'=>setFormComponentValue($companyAssessor,'truck_weight_abattoir_arrival'),
                            'placeholder'=>'Enter Truck Weight Abattoir Arrival',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>



                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Deads On Arrival',
                            'name'=>'deads_on_arrival',
                            'value'=>setFormComponentValue($companyAssessor,'deads_on_arrival'),
                            'placeholder'=>'Enter Deads On Arrival',
                            'parent_class'=>'col-md-6 form-required'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                        </div>
                    </div>
                </div>

                <div class="card-header p-2" id="minerals-section-header">
                    <h2 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse"
                                data-target="#minerals-section">
                            Minerals
                        </button>
                    </h2>
                </div>
                <div id="minerals-section" class="collapse" data-parent="#assessor-live-broiler-form">
                    <div class="card-body">
                        <div class="row">
                            <input type="hidden" name="company_location_id" value="<?php echo e($companyEvaluation->id); ?>">
                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Zinc',
                            'name'=>'zinc',
                            'value'=>setFormComponentValue($companyAssessor,'zinc'),
                            'placeholder'=>'Enter Zinc',
                            'parent_class'=>'col-md-6 '
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Availa Zinc',
                            'name'=>'availa_zinc',
                           'value'=>setFormComponentValue($companyAssessor,'availa_zinc'),
                            'placeholder'=>'Enter Availa Zinc',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>


                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Availa Zinc Concentration',
                            'name'=>'availa_zinc_concentration',
                            'value'=>setFormComponentValue($companyAssessor,'availa_zinc_concentration'),
                            'placeholder'=>'Enter Availa Zinc Concentration',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Availa Zinc Cost',
                            'name'=>'availa_zinc_cost',
                            'value'=>setFormComponentValue($companyAssessor,'availa_zinc_cost'),
                            'placeholder'=>'Enter Availa Zinc Cost',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Manganese',
                            'name'=>'manganese',
                            'value'=>setFormComponentValue($companyAssessor,'manganese'),
                            'placeholder'=>'Enter Manganese',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Availa Manganese',
                            'name'=>'availa_manganese',
                            'value'=>setFormComponentValue($companyAssessor,'availa_manganese'),
                            'placeholder'=>'Enter Availa Manganese',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Availa Manganese Concentration',
                            'name'=>'availa_manganese_concentration',
                            'value'=>setFormComponentValue($companyAssessor,'availa_manganese_concentration'),
                            'placeholder'=>'Enter Availa Manganese Concentration',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                            'label'=>'Availa Manganese Cost',
                            'name'=>'avail_maanganese_cost',
                            'value'=>setFormComponentValue($companyAssessor,'avail_maanganese_cost'),
                            'placeholder'=>'Enter Availa Manganese Cost',
                            'parent_class'=>'col-md-6'
                            ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-text',[
                           'label'=>'Iron',
                           'name'=>'iron',
                           'value'=>setFormComponentValue($companyAssessor,'iron'),
                           'placeholder'=>'Enter Iron',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Iron',
                           'name'=>'availa_iron',
                           'value'=>setFormComponentValue($companyAssessor,'availa_iron'),
                           'placeholder'=>'Enter Availa Iron',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.form.input-text',[
                           'label'=>'Availa Iron Concentration',
                           'name'=>'availa_iron_concentration',
                           'value'=>setFormComponentValue($companyAssessor,'availa_iron_concentration'),
                           'placeholder'=>'Enter Availa Iron Concentration',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Iron Cost',
                           'name'=>'availa_iron_cost',
                           'value'=>setFormComponentValue($companyAssessor,'availa_iron_cost'),
                           'placeholder'=>'Enter Availa Iron Cost',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                               'label'=>'Copper',
                               'name'=>'copper',
                               'value'=>setFormComponentValue($companyAssessor,'copper'),
                               'placeholder'=>'Enter Copper',
                               'parent_class'=>'col-md-6'
                               ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Copper',
                           'name'=>'availa_copper',
                           'value'=>setFormComponentValue($companyAssessor,'availa_copper'),
                           'placeholder'=>'Enter Availa Copper',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Copper Concentration',
                           'name'=>'availa_copper_concentration',
                           'value'=>setFormComponentValue($companyAssessor,'availa_copper_concentration'),
                           'placeholder'=>'Enter Availa Copper Concentration',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Copper Cost',
                           'name'=>'availa_copper_cost',
                           'value'=>setFormComponentValue($companyAssessor,'availa_copper_cost'),
                           'placeholder'=>'Enter Availa Copper Cost',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Chromium',
                           'name'=>'availa_chromium',
                           'value'=>setFormComponentValue($companyAssessor,'availa_chromium'),
                           'placeholder'=>'Enter Availa Chromium',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Chromium Concentration',
                           'name'=>'availa_chromium_concentration',
                           'value'=>setFormComponentValue($companyAssessor,'availa_chromium_concentration'),
                           'placeholder'=>'Enter Availa Chromium Concentration',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                          'label'=>'Availa Chromium Cost',
                          'name'=>'availa_chromium_cost',
                          'value'=>setFormComponentValue($companyAssessor,'availa_chromium_cost'),
                          'placeholder'=>'Enter Availa Chromium Cost',
                          'parent_class'=>'col-md-6'
                          ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                          'label'=>'Selenium',
                          'name'=>'selenium',
                          'value'=>setFormComponentValue($companyAssessor,'selenium'),
                          'placeholder'=>'Enter Selenium',
                          'parent_class'=>'col-md-6'
                          ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Selenium',
                           'name'=>'availa_selenium',
                           'value'=>setFormComponentValue($companyAssessor,'availa_selenium'),
                           'placeholder'=>'Enter Availa Selenium',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Selenium Concentration',
                           'name'=>'availa_selenium_concentration',
                           'value'=>setFormComponentValue($companyAssessor,'availa_selenium_concentration'),
                           'placeholder'=>'Enter Availa Selenium Concentration',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>

                            <?php $__env->startComponent('components.form.input-number',[
                           'label'=>'Availa Selenium Cost',
                           'name'=>'availa_selenium_cost',
                           'value'=>setFormComponentValue($companyAssessor,'availa_selenium_cost'),
                           'placeholder'=>'Enter Availa Selenium Cost',
                           'parent_class'=>'col-md-6'
                           ]); ?>
                            <?php echo $__env->renderComponent(); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="text-right mt-3">
                <button type="submit" class="btn btn-primary">
                    <?php if(empty($companyAssessor)): ?> Add <?php else: ?> Edit <?php endif; ?> Assessor
                </button>
                <a href="<?php echo e(route('company-assessor-list',[ 'company_id' => $company->id, 'company_location_id' => $company_location->id,'company_evaluation_id'=>$companyEvaluation->id])); ?>"
                   class="btn btn-danger">Cancel</a>
            </div>
        </form>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/assessor/form.blade.php ENDPATH**/ ?>
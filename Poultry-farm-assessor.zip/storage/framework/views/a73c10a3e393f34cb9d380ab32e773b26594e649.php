<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('components.UI.header-breadcrumb',['breadcrumbs'=>$breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div>
            <h3><?php echo e($company->company_name); ?></h3>
        </div>
        <div class="clearfix text-right">
            <a href="<?php echo e(route('home')); ?>"
               class="btn btn-success">
                Back
            </a>
            <a href="<?php echo e(route('add-Company-location',['company_id' => $company->id])); ?>"
               class="btn btn-primary">
                Add Company Location
            </a>
        </div>
        <div class="mt-2">
            <div class="row">
                <?php $__currentLoopData = $company->companyLocation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companyLocation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 col-lg-3 col-sm-6 ">
                        <div class="card">
                            <div class="card-body">
                                <h4><?php echo e($companyLocation->name_location); ?></h4>
                                <span class="badge badge-info"><?php echo e($companyLocation->type_location); ?></span>
                                <div class="dropdown top-right-corner">
                                    <span class="fa fa-ellipsis-v p-3 cursor-pointer"
                                          data-toggle="dropdown" aria-haspopup="true"
                                          aria-expanded="false">
                                    </span>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                        <a class="dropdown-item"
                                           href=<?php echo e(route('Company-location-edit', ['company_id' => $companyLocation->company_id, 'company_location_id' => $companyLocation->id])); ?>>Edit</a>

                                        <a class="dropdown-item" href="#"
                                           onclick="confirmDelete('delete-company-location-form-<?php echo e($companyLocation->id); ?>',event)">
                                            Delete
                                        </a>

                                        <form id="delete-company-location-form-<?php echo e($companyLocation->id); ?>"
                                              action="<?php echo e(route('delete-company-location', ['company_id' => $companyLocation->company_id, 'company_location_id' => $companyLocation->id])); ?>"
                                              method="POST" class="d-none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <a class="btn btn-primary"
                                       href=<?php echo e(route('company-evaluation-list', [ 'company_id' => $companyLocation->company_id ,'company_location_id' => $companyLocation->id])); ?>>
                                        <i class="fa fa-long-arrow-alt-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        function confirmDelete(formId, e) {
            const confirmation = confirm("Are you sure?");
            if (confirmation) {
                e.preventDefault();
                document.getElementById(formId).submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app',['datatable'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/company/details.blade.php ENDPATH**/ ?>
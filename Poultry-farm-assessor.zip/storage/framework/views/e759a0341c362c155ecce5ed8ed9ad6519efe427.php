<?php
    $class = isset($class) ? $class : '';
    $parent_class = isset($parent_class) ? $parent_class : '';
    $other = isset($other) ? $other : '';
    $value = isset($value) ? $value : null;
    $unselectable = isset($unselectable) ? $unselectable : false;
?>
<div class="form-group <?php echo e($parent_class); ?>">
    <label for="<?php echo e($name); ?>"><?php echo app('translator')->get($label); ?></label>
    <select
        class="custom-select <?php echo e($class); ?> <?php echo e($errors->has(str_replace(array('[',']'),'',$name)) ? ' is-invalid' : ''); ?>"
        id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" <?php echo $other; ?>>
        <?php if($unselectable): ?>
            <option selected value=""><?php echo app('translator')->get($unselectable); ?></option>
        <?php endif; ?>
        <?php echo e($slot); ?>

    </select>
    <?php if($errors->has($name)): ?>
        <span class="invalid-feedback"><?php echo e(isset($error_msg)?$error_msg:$errors->first($name)); ?></span>
    <?php endif; ?>
</div>
<?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/components/form/input-select.blade.php ENDPATH**/ ?>
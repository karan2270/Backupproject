<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('components.UI.header-breadcrumb',['breadcrumbs'=>$breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h3>View Assessor <?php echo e($liveBroilerData['company_evaluation_id']); ?></h3>

        <div class="clearfix my-3">
            <div class="float-right">

                <a href="<?php echo e(route('company-assessor-list',[ 'company_id' => $company->id, 'company_location_id' => $company_location->id,'company_evaluation_id'=>$liveBroilerData['company_evaluation_id']])); ?>"
                   class="btn btn-primary">Back </a>
                <a href="<?php echo e(route('edit-live-broiler',[ 'company_id' => $company->id, 'company_location_id' => $company_location->id,'company_evaluation_id'=>$liveBroilerData['company_evaluation_id'],'company_assessor_id'=>$liveBroilerData['id']])); ?>"
                   class="btn btn-primary">Edit </a>
            </div>
        </div>


        <div class="card">
            <div class="card-body">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-information-tab" data-toggle="tab"
                           href="#INFORMATION"
                           role="tab" aria-controls="nav-information" aria-selected="true">INFORMATION</a>

                        <a class="nav-item nav-link" id="nav-Broiler-tab" data-toggle="tab" href="#nav-Broiler"
                           role="tab" aria-controls="nav-Broiler" aria-selected="false">BROILER</a>

                        <a class="nav-item nav-link" id="nav-feed-tab" data-toggle="tab" href="#nav-feed"
                           role="tab" aria-controls="nav-feed" aria-selected="false">FEED</a>

                        <a class="nav-item nav-link" id="nav-load-tab" data-toggle="tab" href="#nav-load"
                           role="tab" aria-controls="nav-load" aria-selected="false">LOAD</a>

                        <a class="nav-item nav-link" id="nav-minerals-tab" data-toggle="tab" href="#nav-minerals"
                           role="tab" aria-controls="nav-minerals" aria-selected="false">MINERALS</a>

                        <a class="nav-item nav-link" id="nav-Roi-tab" data-toggle="tab" href="#nav-Roi"
                           role="tab" aria-controls="nav-Roi" aria-selected="false">ROI</a>

                    </div>
                </nav>
                <div class="tab-content" id="nav-tabContent">
                    <div class="tab-pane fade show active" id="INFORMATION" role="tabpanel"
                         aria-labelledby="nav-information-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Trial Group</th>
                                <td><?php echo e($liveBroilerData['trial_group']); ?></td>
                            </tr>
                            <tr>
                                <th>House</th>
                                <td><?php echo e($liveBroilerData['house']); ?></td>
                            </tr>
                            <tr>
                                <th>Genetic</th>
                                <td><?php echo e($liveBroilerData['genetic']); ?></td>
                            </tr>
                            <tr>
                                <th>Number Animals</th>
                                <td><?php echo e($liveBroilerData['number_animals']); ?></td>
                            </tr>
                            <tr>
                                <th>Breeders Age</th>
                                <td><?php echo e($liveBroilerData['breeders_age']); ?></td>
                            </tr>
                            <tr>
                                <th>Chick Weight</th>

                                <td><?php echo e($liveBroilerData['chick_weight']); ?></td>
                            </tr>
                            <tr>
                                <th>Final Weight</th>
                                <td><?php echo e($liveBroilerData['final_weight']); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-Broiler" role="tabpanel" aria-labelledby="nav-Broiler-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Date Of Entry</th>
                                <td><?php echo e($liveBroilerData['date_of_entry']); ?></td>
                            </tr>
                            <tr>
                                <th>Mortality</th>
                                <td><?php echo e($liveBroilerData['mortality']); ?></td>
                            </tr>
                            <tr>
                                <th>Culling</th>
                                <td><?php echo e($liveBroilerData['culling']); ?></td>
                            </tr>
                            <tr>
                                <th>Sex</th>
                                <td><?php echo e($liveBroilerData['hatched']); ?></td>
                            </tr>
                            <tr>
                                <th>Date Harvest</th>
                                <td><?php echo e($liveBroilerData['date_harvest']); ?></td>
                            </tr>
                            <tr>
                                <th>Thinning</th>
                                <td><?php echo e($liveBroilerData['thinning']); ?></td>
                            </tr>
                            <tr>
                                <th>Thinning Number Animals</th>
                                <td><?php echo e($liveBroilerData['thinning_number_animals']); ?></td>
                            </tr>
                            <tr>
                                <th>Thinning Weight</th>
                                <td><?php echo e($liveBroilerData['thinning_weight']); ?></td>
                            </tr>
                            <tr>
                                <th>Market Price</th>
                                <td><?php echo e($liveBroilerData['market_price']); ?></td>
                            </tr>
                            <tr>
                                <th>Growing Period</th>
                                <td><?php echo e($liveBroilerData['growing_period']); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-feed" role="tabpanel" aria-labelledby="nav-feed-tab">
                        <table class="table table-striped">
                            <tbody>

                            <tr>
                                <th>Feed Name 1</th>
                                <td><?php echo e($liveBroilerData['feed_name_1']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 1</th>
                                <td><?php echo e($liveBroilerData['feed_consumption_1']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Cost 1</th>
                                <td><?php echo e($liveBroilerData['feed_cost_1']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Name 2</th>
                                <td><?php echo e($liveBroilerData['feed_name_2']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 2</th>
                                <td><?php echo e($liveBroilerData['feed_consumption_2']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed cost 2</th>
                                <td><?php echo e($liveBroilerData['feed_cost_2']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Name 3</th>
                                <td><?php echo e($liveBroilerData['feed_name_3']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 3</th>
                                <td><?php echo e($liveBroilerData['feed_consumption_3']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed cost 3</th>
                                <td><?php echo e($liveBroilerData['feed_cost_3']); ?></td>
                            </tr>
                            <tr>
                                <th>Fedd Name 4</th>
                                <td><?php echo e($liveBroilerData['feed_name_4']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Consumption 4</th>
                                <td><?php echo e($liveBroilerData['feed_consumption_4']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Cost 4</th>
                                <td><?php echo e($liveBroilerData['feed_cost_4']); ?></td>
                            </tr>
                            <tr>
                                <th>Feed Withdrawal</th>
                                <td><?php echo e($liveBroilerData['feed_withdrawal']); ?></td>
                            </tr>
                            <tr>
                                <th>Total Consumption Feed</th>
                                <td><?php echo e($liveBroilerData['total_consumption__feed']); ?></td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-load" role="tabpanel" aria-labelledby="nav-load-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Truck weight Farm exit</th>
                                <td><?php echo e($liveBroilerData['truck_weight_farm_exit']); ?></td>
                            </tr>
                            <tr>
                                <th>Truck weight abattoir arrival</th>
                                <td><?php echo e($liveBroilerData['truck_weight_abattoir_arrival']); ?></td>
                            </tr>
                            <tr>
                                <th>Trasport weight loss</th>
                                <td><?php echo e($liveBroilerData['transport_weight_loss']); ?></td>
                            </tr>
                            <tr>
                                <th>Deads on arrival</th>
                                <td><?php echo e($liveBroilerData['deads_on_arrival']); ?></td>

                            </tr>
                            <tr>
                                <th>Liveability</th>
                                <td><?php echo e($liveBroilerData['liveability']); ?></td>

                            </tr>
                            <tr>

                                <th>Live birds for abattoir</th>
                                <td><?php echo e($liveBroilerData['live birds for abattoir']); ?></td>

                            </tr>
                            <tr>
                                <th>FCR</th>
                                <td><?php echo e($liveBroilerData['FCR']); ?></td>

                            </tr>
                            <tr>
                                <th>Mortality and culling</th>
                                <td><?php echo e($liveBroilerData['Mortality and culling']); ?></td>

                            </tr>
                            <tr>
                                <th>Adjusted FCR</th>
                                <td><?php echo e($liveBroilerData['Adjusted FCR']); ?></td>

                            </tr>
                            <tr>
                                <th>Average Daily Gain</th>
                                <td><?php echo e($liveBroilerData['Average Daily Gain']); ?></td>

                            </tr>
                            <tr>
                                <th>Average Daily feed Intake</th>
                                <td><?php echo e($liveBroilerData['Average Daily Feed Intake']); ?></td>

                            </tr>
                            <tr>
                                <th>Total Feed Cost per bird</th>
                                <td><?php echo e($liveBroilerData['Total Feed Cost per bird']); ?></td>

                            </tr>
                            <tr>
                                <th>Avg Feed Cost</th>
                                <td><?php echo e($liveBroilerData['Avg Feed Cost']); ?></td>

                            </tr>
                            <tr>
                                <th>Cost of availa Inclusion</th>
                                <td><?php echo e($liveBroilerData['Cost Of Availa Inclusion']); ?></td>

                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-minerals" role="tabpanel" aria-labelledby="nav-minerals-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Zinc</th>
                                <td><?php echo e($liveBroilerData['zinc']); ?></td>
                            </tr>
                            <tr>
                                <th>Aaila Zinc</th>
                                <td><?php echo e($liveBroilerData['availa_zinc']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Zinc Concentration</th>
                                <td><?php echo e($liveBroilerData['availa_zinc_concentration']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Zinc Cost</th>
                                <td><?php echo e($liveBroilerData['availa_zinc_cost']); ?></td>
                            </tr>
                            <tr>
                                <th>Manganese</th>
                                <td><?php echo e($liveBroilerData['manganese']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Manganese</th>
                                <td><?php echo e($liveBroilerData['availa_manganese']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Manganese Concentration</th>
                                <td><?php echo e($liveBroilerData['availa_manganese_concentration']); ?></td>
                            </tr>
                            <tr>
                                <th>Avail Maanganese Cost</th>
                                <td><?php echo e($liveBroilerData['avail_maanganese_cost']); ?></td>
                            </tr>
                            <tr>
                                <th>Iron</th>
                                <td><?php echo e($liveBroilerData['iron']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Iron</th>
                                <td><?php echo e($liveBroilerData['availa_iron']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Iron Concentration</th>
                                <td><?php echo e($liveBroilerData['availa_iron_concentration']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Iron Cost</th>
                                <td><?php echo e($liveBroilerData['availa_iron_cost']); ?></td>
                            </tr>
                            <tr>
                                <th>Copper</th>
                                <td><?php echo e($liveBroilerData['copper']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Copper</th>
                                <td><?php echo e($liveBroilerData['availa_copper']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Copper Concentration</th>
                                <td><?php echo e($liveBroilerData['availa_copper_concentration']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Copper Cost</th>
                                <td><?php echo e($liveBroilerData['availa_copper_cost']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Chromium</th>
                                <td><?php echo e($liveBroilerData['availa_chromium']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Chromium Concentration</th>
                                <td><?php echo e($liveBroilerData['availa_chromium_concentration']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Chromium Cost</th>
                                <td><?php echo e($liveBroilerData['availa_chromium_cost']); ?></td>
                            </tr>
                            <tr>
                                <th>Selenium</th>
                                <td><?php echo e($liveBroilerData['selenium']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Selenium</th>
                                <td><?php echo e($liveBroilerData['availa_selenium']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Selenium Concentration</th>
                                <td><?php echo e($liveBroilerData['availa_selenium_concentration']); ?></td>
                            </tr>
                            <tr>
                                <th>Availa Selenium Cost</th>
                                <td><?php echo e($liveBroilerData['availa_selenium_cost']); ?></td>


                            </tr>
                            <tr>
                                <th>Cost of Availa Inclusion</th>
                                <td><?php echo e($liveBroilerData['Cost Of Availa Inclusion']); ?></td>


                            </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="nav-Roi" role="tabpanel" aria-labelledby="nav-Roi-tab">
                        <table class="table table-striped">
                            <tbody>
                            <tr>
                                <th>Value Of Sale</th>
                                <td><?php echo e($liveBroilerData['Value of Sale']); ?></td>
                            </tr>
                            <tr>
                                <th>Income</th>
                                <td><?php echo e($liveBroilerData['Income']); ?></td>
                            </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/assessor/view.blade.php ENDPATH**/ ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="breadcrumb-item <?php if($breadcrumb['active']): ?> active <?php endif; ?>">
                <?php if(empty($breadcrumb['link'])): ?>
                    <?php echo e($breadcrumb['title']); ?>

                <?php else: ?>
                    <a href="<?php echo e($breadcrumb['link']); ?>"><?php echo e($breadcrumb['title']); ?></a>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>
<?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/components/UI/header-breadcrumb.blade.php ENDPATH**/ ?>
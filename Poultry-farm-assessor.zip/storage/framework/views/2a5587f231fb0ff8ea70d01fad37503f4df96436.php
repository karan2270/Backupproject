<?php
    $placeholder = isset($placeholder) ? $placeholder : '';
    $class = isset($class) ? $class : '';
    $parent_class = isset($parent_class) ? $parent_class : '';
    $other = isset($other) ? $other : '';
?>
<div class="form-group <?php echo e($parent_class); ?>">
    <label for="<?php echo e($name); ?>"><?php echo e($label); ?></label>
    <input type="number" class="form-control <?php echo e($class); ?> <?php echo e($errors->has($name) ? ' is-invalid' : ''); ?>"
           id="<?php echo e($name); ?>" name="<?php echo e($name); ?>" placeholder="<?php echo e($placeholder); ?>"
           value="<?php echo e($value); ?>" step="any" <?php echo e($other); ?>>
    <?php if($errors->has($name)): ?>
        <span class="invalid-feedback"><?php echo e(isset($error_msg)?$error_msg:$errors->first($name)); ?></span>
    <?php endif; ?>
</div>
<?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/components/form/input-number.blade.php ENDPATH**/ ?>
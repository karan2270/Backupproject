<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('components.UI.header-breadcrumb',['breadcrumbs'=>$breadcrumbs], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h4>Assessors : <?php echo e($companyEvaluation->first_name); ?> <?php echo e($companyEvaluation->last_name); ?></h4>
        <div class="clearfix my-3">
            <a href="<?php echo e(route('company-evaluation-list', ['company_id' => $company_id, 'company_location_id' => $company_location->id])); ?>"
               class="btn btn-primary float-right">Back </a>
        </div>
        <div class="row">
            <div class="col-3">
                <div class="card">
                    <div class="card-body">
                        <?php if($liveBroiler): ?>
                            <a href="<?php echo e(route('company-assessor-view', ['company_id' => $company_id, 'company_location_id' => $company_location->id, 'company_evaluation_id' => $companyEvaluation->id])); ?>">Live
                                Broiler
                                Assessor</a>
                        <?php else: ?>
                            <a href="<?php echo e(route('add-liveBroiler-assessor',[ 'company_id' => $company_id,  'company_location_id'=>$company_location->id ,'company_evaluation_id'=>$companyEvaluation->id])); ?>">Live
                                Broiler
                                Assessor</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card">
                    <div class="card-body">

                        <a>Academy Assessor</a>

                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card">
                    <div class="card-body">

                        <a >Report Assessor</a>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/company-evaluation/details.blade.php ENDPATH**/ ?>
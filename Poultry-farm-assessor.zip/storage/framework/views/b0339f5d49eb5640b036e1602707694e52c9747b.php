<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="clearfix">
            <a href="<?php echo e(route('add-company')); ?>" class="btn btn-primary float-right">Add Company</a>
        </div>
        <div class="mt-2">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered table-sm" id="company-list"></table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra-js'); ?>
    <script>
        $('#company-list').dataTable({
            ajax: {
                type: 'POST',
                url: "<?php echo e(route('company-datatable')); ?>",
            },
            processing: true,
            serverSide: true,
            responsive: true,
            columns: [
                {data: 'id', title: 'ID'},
                {data: 'company_name', title: 'Company  Name'},
                {data: 'contact_name', title: 'Contact  Name'},
                {data: 'email', title: '  Email'},
                {data: 'phone', title: ' Phone'},
                {data: 'address', title: 'Address'},
                {data: 'country', title: 'Country'},
                {data: 'actions', title: 'Actions'},
            ],
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app',['datatable'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/home.blade.php ENDPATH**/ ?>
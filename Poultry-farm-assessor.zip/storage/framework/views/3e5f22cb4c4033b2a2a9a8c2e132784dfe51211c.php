<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <?php if(empty($companyLocation)): ?> Add <?php else: ?> Edit <?php endif; ?> Company Location
            </div>
            <div class="card-body">
                <form action="<?php echo e($routeToSave); ?>" method="post" class="row">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="company_id" value="<?php echo e($company->id); ?>">

                    <?php $__env->startComponent('components.form.input-select',[
                    'label'=>'Type of Location',
                    'name'=>'type_location',
                    'value'=>setFormComponentValue($companyLocation,'type_location'),
                    'parent_class'=>'col-md-6 form-required'
                    ]); ?>
                        <option value="farm">Farm</option>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Name Location',
                    'name'=>'name_location',
                    'value'=>setFormComponentValue($companyLocation,'name_location'),
                    'placeholder'=>'Enter Location',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($companyLocation,'email'),
                    'placeholder'=>'Enter email',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Phone',
                    'name'=>'phone',
                    'value'=>setFormComponentValue($companyLocation,'phone'),
                    'placeholder'=>'Enter phone',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Address',
                    'name'=>'address',
                    'value'=>setFormComponentValue($companyLocation,'address'),
                    'placeholder'=>'Enter address',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Contact name',
                    'name'=>'contact_name',
                    'value'=>setFormComponentValue($companyLocation,'contact_name'),
                    'placeholder'=>'Enter Contact Name',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Country ',
                    'name'=>'country',
                    'value'=>setFormComponentValue($companyLocation,'country'),
                    'placeholder'=>'Enter Country',
                    'parent_class'=>'col-md-6'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <?php if(empty($companyLocation)): ?> Add <?php else: ?> Edit <?php endif; ?> Company Location
                        </button>
                               <a href="<?php echo e(route('company-location-list',['company_id'=>$company['id']])); ?>" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/company-location/form.blade.php ENDPATH**/ ?>
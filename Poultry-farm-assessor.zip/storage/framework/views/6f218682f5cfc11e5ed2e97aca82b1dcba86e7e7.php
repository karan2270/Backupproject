<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <?php if(empty($user)): ?> Add <?php else: ?> Edit <?php endif; ?> User
            </div>
            <div class="card-body">
                <form action="<?php echo e($routeToSave); ?>" method="post" class="row">
                    <?php echo csrf_field(); ?>

                    <?php $__env->startComponent('components.form.input-text',[
                    'label'=>'Name',
                    'name'=>'name',
                    'value'=>setFormComponentValue($user,'name'),
                    'placeholder'=>'Enter User Name',
                    'parent_class'=>'col-md-6 form-required'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-email',[
                    'label'=>'Email',
                    'name'=>'email',
                    'value'=>setFormComponentValue($user,'email'),
                    'placeholder'=>'Enter User Email',
                    'parent_class'=>'col-md-6 form-required'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-password',[
                    'label'=>'Password',
                    'name'=>'password',
                    'placeholder'=>'Enter User password',
                    'parent_class'=>'col-md-6 form-required'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-password',[
                    'label'=>'Confirm Password',
                    'name'=>'confirmed',
                    'placeholder'=>'Enter Confirm password',
                    'parent_class'=>'col-md-6 form-required'
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <?php $__env->startComponent('components.form.input-radio',[
                    'label'=>'Is Admin',
                    'name'=>'is_admin',
                    'value'=>setFormComponentValue($user,'is_admin'),
                    'class'=>'custom-control-inline',
                    'parent_class'=>'col-md-12',
                    'items'=>[['label'=>'Admin','value'=>'1'],['label'=>'User','value'=>'0']]
                    ]); ?>
                    <?php echo $__env->renderComponent(); ?>

                    <div class="col-12">
                        <button type="submit" class="btn btn-primary">
                            <?php if(empty($user)): ?> Add <?php else: ?> Edit <?php endif; ?> User
                        </button>
                        <a href="<?php echo e(route('user-list')); ?>" class="btn btn-danger">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/users/add.blade.php ENDPATH**/ ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Company-List</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('company-location-list', ['company_id' => $companyEvaluation->company_id])); ?>">Company-Location-List</a></Location-List></a></li>
        <li class="breadcrumb-item active">Evaluation-List</li>
    </ol>
</nav>
<?php /**PATH /opt/lampp/htdocs/poultry-farm-assessor/resources/views/header/header-breadcrumb.blade.php ENDPATH**/ ?>

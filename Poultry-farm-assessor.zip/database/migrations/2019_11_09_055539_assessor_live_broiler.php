<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AssessorLiveBroiler extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assessor_live_broiler', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('company_evaluation_id');
            $table->string('trial_group')->nullable();
            $table->string('house')->nullable();
            $table->string('genetic')->nullable();
            $table->string('number_animals')->nullable();
            $table->string('breeders_age')->nullable();
            $table->string('chick_weight')->nullable();
            $table->string('final_weight')->nullable();
            $table->string('mortality')->nullable();
            $table->string('culling')->nullable();
            $table->string('hatched')->nullable();
            $table->string('date_harvest')->nullable();
            $table->string('thinning')->nullable();
            $table->string('thinning_number_animals')->nullable();
            $table->string('thinning_weight')->nullable();
            $table->string('market_price')->nullable();
            $table->string('growing_period')->nullable();
            $table->string('feed_name_1')->nullable();
            $table->string('feed_consumption_1')->nullable();
            $table->string('feed_cost_1')->nullable();
            $table->string('feed_name_2')->nullable();
            $table->string('feed_consumption_2')->nullable();
            $table->string('feed_cost_2')->nullable();
            $table->string('feed_name_3')->nullable();
            $table->string('feed_consumption_3')->nullable();
            $table->string('feed_cost_3')->nullable();
            $table->string('feed_name_4')->nullable();
            $table->string('feed_consumption_4')->nullable();
            $table->string('feed_cost_4')->nullable();
            $table->string('feed_withdrawal')->nullable();
            $table->string('total_consumption__feed')->nullable();
            $table->string('truck_weight_farm_exit')->nullable();
            $table->string('truck_weight_abattoir_arrival')->nullable();
            $table->string('deads_on_arrival')->nullable();
            $table->decimal('zinc',11,2)->default(0.0);
            $table->string('availa_zinc')->nullable();
            $table->string('availa_zinc_concentration')->nullable();
            $table->string('availa_zinc_cost')->nullable();
            $table->string('manganese')->nullable();
            $table->string('availa_manganese')->nullable();
            $table->string('availa_manganese_concentration')->nullable();
            $table->string('avail_maanganese_cost')->nullable();
            $table->string('iron')->nullable();
            $table->string('availa_iron')->nullable();
            $table->string('availa_iron_concentration')->nullable();
            $table->string('availa_iron_cost')->nullable();
            $table->string('copper')->nullable();
            $table->string('availa_copper')->nullable();
            $table->string('availa_copper_concentration')->nullable();
            $table->string('availa_copper_cost')->nullable();
            $table->string('availa_chromium')->nullable();
            $table->string('availa_chromium_concentration')->nullable();
            $table->string('availa_chromium_cost')->nullable();
            $table->string('selenium')->nullable();
            $table->string('availa_selenium')->nullable();
            $table->string('availa_selenium_concentration')->nullable();
            $table->string('availa_selenium_cost')->nullable();

            $table->unsignedBigInteger('created_by');
            $table->timestamps();

            $table->foreign('company_evaluation_id')
                ->references('id')->on('company_evaluations')
                ->onUpdate('cascade')->onDelete('cascade');


            $table->foreign('created_by')
                ->references('id')->on('users')
                ->onUpdate('cascade')->onDelete('cascade');
        });


}

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assessor_live_broiler');
    }
}

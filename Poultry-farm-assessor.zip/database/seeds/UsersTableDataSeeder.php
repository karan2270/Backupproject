<?php

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UsersTableDataSeeder extends Seeder
{
    public function run()
    {
        DB::table('users')->insert([
            [
                'name' => 'Karan Kadiya',
                'email' => 'karan@mail.com',
                'password' => bcrypt('123456789'),
                'api_token' => Str::random(60),
                'is_admin' => true
            ],
            [
                'name' => 'Rahul Chavda',
                'email' => 'rahul.chavda@ebiz.com',
                'password' => bcrypt('rahul123'),
                'api_token' => Str::random(60),
                'is_admin' => true
            ],
        ]);
    }
}
